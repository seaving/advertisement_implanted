
#ifndef __QOS_NETLINK_H__
#define __QOS_NETLINK_H__




int create_net_dev_monitor_thread();
void nl_log(const char* fmt, ...);





#endif


