#ifndef __UDP_CLIENT_H__
#define __UDP_CLIENT_H__


int create_udp_client();




#endif



