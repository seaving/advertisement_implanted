#ifndef __ID_H__
#define __ID_H__

#define ID             "default000000"

#define PLATFORMS      "ar9344"

#define MODULE_NAME	 "ap"


#endif
