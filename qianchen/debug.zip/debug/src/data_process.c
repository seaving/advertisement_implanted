#include "includes.h"

/**
AC����APͨ���㲥
AC��������APͨ��UDP
*/

int data_process(int ufd, struct sockaddr_in *from, char *buf, int len)
{
	LOG_HL_INFO("len: %d, buf: %s\n", len, buf);

	//udp_send_to(ufd, buf, len, UDP_BROADCAST, AP_CLIENT_PORT);
	udp_send_to(ufd, buf, len, "134.227.255.255", AP_CLIENT_PORT);
	
	return 0;
}

