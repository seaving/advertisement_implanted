#ifndef __DATA_PROCESS_H__
#define __DATA_PROCESS_H__

#include "common.h"

int data_process(int ufd, struct sockaddr_in *from, char *buf, int len);


#endif

