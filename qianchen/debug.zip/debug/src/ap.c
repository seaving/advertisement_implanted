#include "includes.h"


/**
* ֪ͨAC������AP
*/
int access_to_ac(char *ip, char *mac)
{
	char gw[32];
	get_gateway(gw);
	if (gw)
}



