#ifndef __CONFIG_H__
#define __CONFIG_H__

#define LAN_DEV		"br-lan"

#define AC_SERVER_PORT	61000
#define AP_CLIENT_PORT	61001

#endif

