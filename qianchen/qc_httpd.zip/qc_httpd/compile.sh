#!/bin/bash

PLATFORMS=$1
DEBUG_ON=$2
VERSION=`cat src/version.h | grep -w VERSION | awk -F " " '{print $3}' | awk -F '"' '{print $2}'`
TARGET_NAME="qchttpd"
useage() {
	echo "PLATFORMS is selection, [0]: AR9344, [1]: MT7620, [2]: PC, [3]: x86."
	echo "DEBUG_ON is selection, [0]: disable log print, [1]: log enable."
	#echo "TARGET_NAME is the program bin name by yourself."
}

[ $# -eq 1 ] && [ "$1" == "-h" ] && {
	useage
	exit
}

[ -z "$VERSION" ] && echo "not define version!" && exit

[ -z "$PLATFORMS" ] || [ -z "$TARGET_NAME" ] || [ -z "$DEBUG_ON" ] && {
	echo "please input PLATFORMS, DEBUG_ON!"
	useage
	exit
}

case $PLATFORMS in
	"0") { PLATFORMS="ar9344"; OP_DIR="ar9344_OpenWrt"; }
	;;
	"1") { PLATFORMS="mt7620"; OP_DIR="ar9344_OpenWrt"; }
	;;
	"2") PLATFORMS="pc";
	;;
	"3") { PLATFORMS="x86"; OP_DIR="x86_openwrt"; }
	;;
	*) echo "PLATFORMS is selection, [0]: AR9344, [1]: MT7620, [2]: PC, [3]: x86.";exit
	;;
esac

rm -rf makefile
sync
cp -rf build/makefile-$PLATFORMS makefile
sync

make clean
make PLATFORMS=$PLATFORMS DEBUG_ON=$DEBUG_ON TARGET_NAME=$TARGET_NAME VERSION=$VERSION 2>./complie.log

complie_log=`cat ./complie.log`
[ -n "$complie_log" ] && {
	err=`cat ./complie.log | grep -w "error:" | wc -l`
	warn=`cat ./complie.log | grep -w "warning:" | wc -l`

	if [ "$err" == "0" ] && [ "$warn" == "1" ]
	then
		complie_log=`echo "$complie_log" | grep "warning: gethostbyname"`
		if [ -n "$complie_log" ]
		then
			echo > ./complie.log
		else
			echo "[ERROR] $complie_log"
			exit
		fi
	else
		echo "[ERROR] $complie_log"
		exit
	fi
}

./package_www.sh
package_www_log=`cat ./package_www.log`
[ -n "$package_www_log" ] && {
	echo "$package_www_log"
	echo "$package_www_log" > ./complie.log
	exit
}

rm -rf ../package/app/$TARGET_NAME
cp -rf hex/$TARGET_NAME ../package/app/
rm -rf ../package/app/www.gz
cp -rf www.gz ../package/app/
sync

echo "rm -rf /home/seaving/$OP_DIR/openwrt/package/base-files/files/etc/app/www.gz"
rm -rf /home/seaving/$OP_DIR/openwrt/package/base-files/files/etc/app/www.gz
echo "cp -rf ./www.gz /home/seaving/$OP_DIR/openwrt/package/base-files/files/etc/app/"
cp -rf ./www.gz /home/seaving/$OP_DIR/openwrt/package/base-files/files/etc/app/
sync

echo "rm -rf /home/seaving/$OP_DIR/openwrt/package/base-files/files/etc/app/$TARGET_NAME"
rm -rf /home/seaving/$OP_DIR/openwrt/package/base-files/files/etc/app/$TARGET_NAME
echo "cp -rf ./hex/$TARGET_NAME /home/seaving/$OP_DIR/openwrt/package/base-files/files/etc/app/"
cp -rf ./hex/$TARGET_NAME /home/seaving/$OP_DIR/openwrt/package/base-files/files/etc/app/
sync

exit
