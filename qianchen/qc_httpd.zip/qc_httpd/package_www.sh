rm -rf www.gz;
sync;
tar zcf www.gz www 2>./package_www.log
