#ifndef __AUTH_H__
#define __AUTH_H__


int auth_server_create();



#endif

