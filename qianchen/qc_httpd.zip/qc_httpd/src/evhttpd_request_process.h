#ifndef __EVHTTPD_REQUEST_PROCESS_H__
#define __EVHTTPD_REQUEST_PROCESS_H__

#include "evhttp_server.h"


int evhttpd_get(struct evhttp_request *req, const t_http_server *http_server);
int evhttpd_post(struct evhttp_request *req, const t_http_server *http_server);


#endif


