#ifndef __CGI_WIRELESS_H__
#define __CGI_WIRELESS_H__

#include "common.h"
#include "evhttp_server.h"

int cgi_get_wireless_info(struct evhttp_request *req, const t_http_server *http_server);

int cgi_set_wireless(struct evhttp_request *req, const t_http_server *http_server);


#endif

