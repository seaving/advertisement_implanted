#include "includes.h"
#include "cgi_config.h"

int evhttp_cgi_service(struct evhttp_request *req, const t_http_server *http_server)
{
	int i;

	char *rapi = evhttp_get_parm(req, "api");
	if (! rapi) return -1;

	for (i = 0; cgi[i].fun && cgi[i].map_name; i ++)
	{
		char *map_api = evhttpd_parse_parma_by_uri(cgi[i].map_name, "api");
		if (! map_api) continue;

		LOG_WARN_INFO("map_api: %s -> cmp -> act_api: %s\n", map_api, rapi);
		if (strcmp(rapi, map_api) == 0)
		{
			LOG_WARN_INFO("map_name: %s find call \n", cgi[i].map_name);

			if (map_api) free(map_api);
			if (rapi) free(rapi);

			return cgi[i].fun(req, http_server);
		}
		
		if (map_api) free(map_api);
	}
	
	if (rapi) free(rapi);
	return -1;
}


