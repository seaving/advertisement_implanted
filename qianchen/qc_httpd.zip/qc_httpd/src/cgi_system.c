#include "includes.h"
#include "cgi_system.h"

int cgi_get_system_info(struct evhttp_request *req, const t_http_server *http_server)
{
	char fw_ver[64] = {0};
	if (get_firmware_version(fw_ver) < 0)
		return -1;

	int run_time = SYSTEM_SEC;
	
	/*int total_ddr_size = (int)get_total_ddr_Size();
	if (total_ddr_size < 0)
	{
		total_ddr_size = 0;
	}

	int used_ddr_size = (int)get_used_ddr_Size();
	if (used_ddr_size < 0)
	{
		used_ddr_size = 0;
	}

	char cpu[125] = {0};
	if (get_cpu_info(cpu) < 0)
	{
		sprintf(cpu, "---");
	}

	char system_version[255] = {0};
	if (get_system_version(system_version) < 0)
	{
		sprintf(system_version, "---");
	}

	char hostname[33] = {0};
	if (get_hostname(hostname) < 0)
	{
		//sprintf(hostname, "---");
	}*/
	
	char model[128] = {0};
	if (get_machine(model) < 0)
	{
		sprintf(model, "---");
	}

	int user_count = get_wifi_client_count();

	char *wan_ip_error = NULL;
	char wan_ip[32] = {0};
	get_dev_ip(wan_ip, get_netdev_wan_name());
	if (strlen(wan_ip) <= 0)
	{
		wan_ip_error = unicode_encode("���ڶԶ��豸δ����ȷ����IP��ַ!");
	}

	char *dns_error = NULL;
	char dns[64] = {0};
	get_dns(dns, 1);
	dns[strlen(dns)] = ' ';
	dns[strlen(dns)] = ',';
	dns[strlen(dns)] = ' ';
	get_dns(&dns[strlen(dns)], 2);
	if (strlen(dns) <= 3)
	{
		dns_error = unicode_encode("���ڶԶ��豸δ����ȷ����DNS��������ַ!");
	}

	char proto[32] = {0};
	get_wan_proto(proto);

	int error = 0;
	char *error_info = NULL;
	if (dns_error || wan_ip_error)
	{
		int calloc_size = (dns_error ? strlen(dns_error) : 0)
						+ (wan_ip_error ? strlen(wan_ip_error) : 0);
		if (calloc_size > 0)
		{
			error_info = calloc(1, calloc_size + 5);
			if (! error_info)
			{
				if (dns_error) utf8_encode_free(dns_error);
				if (wan_ip_error) utf8_encode_free(wan_ip_error);
				return -1;
			}

			sprintf(error_info, "%s\r\n%s\r\n", 
					dns_error ? dns_error : " ",
				wan_ip_error ? wan_ip_error : " ");

			error = 1;
		}
	}

	json_object *my_object = json_object_new_object();
	if (! my_object)
	{
		if (dns_error) utf8_encode_free(dns_error);
		if (wan_ip_error) utf8_encode_free(wan_ip_error);
		if (error_info) free(error_info);
		return -1;
	}
	
	json_object_object_add(my_object, "error", json_object_new_int(error));
	json_object_object_add(my_object, "error_info", json_object_new_string(error_info ? error_info : "no error info"));
	json_object_object_add(my_object, "firmware_version", json_object_new_string(fw_ver));
	json_object_object_add(my_object, "module", json_object_new_string(model));
	json_object_object_add(my_object, "run_time", json_object_new_int(run_time));
	json_object_object_add(my_object, "user_count", json_object_new_int(user_count));
	json_object_object_add(my_object, "device_online_count", json_object_new_int(1));
	json_object_object_add(my_object, "device_offline_count", json_object_new_int(0));
	json_object_object_add(my_object, "proto", json_object_new_string(proto));
	json_object_object_add(my_object, "dns", json_object_new_string(dns));
	json_object_object_add(my_object, "wan_ip", json_object_new_string(wan_ip));

	//json_object_object_add(my_object, "ddr_max", json_object_new_int(total_ddr_size/(1024)));
	//json_object_object_add(my_object, "ddr_used", json_object_new_int(used_ddr_size/(1024)));
	//json_object_object_add(my_object, "cpu", 					json_object_new_string(cpu));
	//json_object_object_add(my_object, "system_version", json_object_new_string(system_version));
	//json_object_object_add(my_object, "model", 					json_object_new_string(model));
	//json_object_object_add(my_object, "hostname", 				json_object_new_string(hostname));
	LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));

	int ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
	json_object_put(my_object);

	if (dns_error) utf8_encode_free(dns_error);
	if (wan_ip_error) utf8_encode_free(wan_ip_error);
	if (error_info) free(error_info);

	return ret;
}

int cgi_reboot(struct evhttp_request *req, const t_http_server *http_server)
{
	char cmd[255];
	EXECUTE_CMD(cmd, "reboot");
	return 0;
}


