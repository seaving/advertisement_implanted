#ifndef __COMMON_OP_H__
#define __COMMON_OP_H__


void uci_commit();

void restart_network();

#endif

