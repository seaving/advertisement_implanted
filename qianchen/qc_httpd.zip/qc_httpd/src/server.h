#ifndef __SERVER_H__
#define __SERVER_H__

#if 0

int server_create();
int create_server_thread();

#endif

#endif

