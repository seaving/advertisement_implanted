#ifndef __CGI_PASSWD_H__
#define __CGI_PASSWD_H__

#include "common.h"
#include "evhttp_server.h"

int cgi_modify_pwd(struct evhttp_request *req, const t_http_server *http_server);
int cgi_reset_pwd(struct evhttp_request *req, const t_http_server *http_server);


#endif


