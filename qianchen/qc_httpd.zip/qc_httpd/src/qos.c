#include "includes.h"

static hashtable_t *_qos_ht_head = NULL;

qos_t *create_qos_node(char *ip, char *handle)
{
	qos_t *qos = calloc(sizeof(qos_t), 1);
	if (! qos)
	{
		LOG_PERROR_INFO("calloc error.");
		return NULL;
	}

	if (ip)
	{
		qos->ip = calloc(1, strlen(ip) + 1);
		if (! qos->ip)
		{
			LOG_PERROR_INFO("calloc error.");
			free(qos);
			return NULL;
		}

		memcpy(qos->ip, ip, strlen(ip));
	}

	if (handle)
	{
		qos->handle = calloc(1, strlen(handle) + 1);
		if (! qos->handle)
		{
			LOG_PERROR_INFO("calloc error.");
			free(qos);
			return NULL;
		}

		memcpy(qos->handle, handle, strlen(handle));
	}

	return qos;
}

void free_qos_node(void *node)
{
	qos_t *qos = (qos_t *)node;
	if (qos)
	{
		if (qos->ip)
			free(qos->ip);
		if (qos->handle)
			free(qos->handle);

		free(qos);
	}
}

int update_qos_handle(qos_t *qos, char *handle)
{
	if (! handle || ! qos)
		return -1;
	
	if (strcmp(qos->handle, handle) == 0)
		return 0;

	if (qos->handle)
		free(qos->handle);
	
	qos->handle = calloc(1, strlen(handle) + 1);
	if (! qos->handle)
	{
		LOG_PERROR_INFO("calloc error.");
		return -1;
	}

	memcpy(qos->handle, handle, strlen(handle));

	return 0;
}

int qos_add(char *ip, char *handle)
{
	char *key = ip;
	qos_t *qos = uthash_find(&_qos_ht_head, key);
	if (! qos)
	{
		qos = create_qos_node(ip, handle);
		if (! qos)
		{
			goto err;
		}

		if (uthash_put(&_qos_ht_head, key, qos, free_qos_node) < 0)
		{
			free_qos_node(qos);
			goto err;
		}
	}
	else
	{
		update_qos_handle(qos, handle);
	}

	return 0;

err:
	return -1;
}

int get_qos_count()
{
	return uthash_count(&_qos_ht_head);
}

