#ifndef __SPEED_LIMIT_WLIST_CACHE_H__
#define __SPEED_LIMIT_WLIST_CACHE_H__

int speed_limit_wip_file_init();
int speed_limit_wip_file_write(char *wip);
char* speed_limit_wip_file_read();
int speed_limit_whost_to_wip(char *whost);
//int speed_limit_defalt_whost_to_ip();


#endif

