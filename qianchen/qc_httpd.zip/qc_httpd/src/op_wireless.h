
#ifndef __WIRELESS_OP_H__
#define __WIRELESS_OP_H__

#define SSID_LEN	33
#define WIFI_PASSWD_LEN	16

int get_wifi_ssid(int witch, char *ssid);
int set_wifi_ssid(int witch, char *ssid);

int get_wifi_txpower(int witch);
int set_wifi_txpower(int witch, unsigned char txpower);

int get_wifi_channel(int witch, char *channel);
int set_wifi_channel(int witch, char *channel);

int get_wifi_mode(int witch, char *mode);
int set_wifi_mode(int witch, char *mode);

int get_wifi_encryption(int witch, char *encryption);
int set_wifi_encryption(int witch, char *encryption);

int get_wifi_key(int witch, char *key);
int set_wifi_key(int witch, char *key);

int get_wifi_disabled(int witch);
int set_wifi_disabled(int witch, unsigned char disabled);

int get_wifi_htmode(int witch, char *htmode);
int set_wifi_htmode(int witch, char *htmode);

int get_wifi_hwmode(int witch, char *hwmode);
int set_wifi_hwmode(int witch, char *hwmode);

int get_wifi_hidden(int witch);
int set_wifi_hidden(int witch, unsigned char hidden);

int scan_wireless_dev();

#endif



