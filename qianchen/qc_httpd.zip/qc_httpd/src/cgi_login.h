#ifndef __CGI_LOGIN_H__
#define __CGI_LOGIN_H__

#include "common.h"
#include "evhttp_server.h"

int cgi_logout(struct evhttp_request *req, const t_http_server *http_server);


#endif

