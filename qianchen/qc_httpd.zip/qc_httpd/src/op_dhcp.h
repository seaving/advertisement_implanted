#ifndef __OP_DHCP_H__
#define __OP_DHCP_H__

int get_dhcp_list(char *list, int page_num, int page_count);


int get_dhcp_leasetime();

int get_dhcp_list_cnt();

int get_dhcp_ippool_min();

int get_dhcp_ippool_max();

int set_dhcp_ippool(int min, int max);
int set_dhcp_leasetime(unsigned char leasetime);

#endif


