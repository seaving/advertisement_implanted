#ifndef __SPEED_LIMIT_API_H__
#define __SPEED_LIMIT_API_H__


#define SET_LAST_SPEED	-1
#define SET_FULL_SPEED	0

//int speed_limit_set_wlist_in_thread(char *wlist);
//int speed_limit_set_rate_in_thread(u32 up_speed, u32 down_speed);

//����ԭ���ӿ�
int qos_stop_rate_limit_in_thread();
int qos_set_rate_limit_in_thread(int up_speed, int down_speed);
void qos_speed_limit_init();

#endif

