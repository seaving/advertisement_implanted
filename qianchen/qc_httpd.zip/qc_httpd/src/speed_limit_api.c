#include "includes.h"

static pthread_mutex_t tc_limit_lock = PTHREAD_MUTEX_INITIALIZER;

void speed_limit_set_wlist(char *wlist)
{
	int offset = 0;
	int i = 0;
	char buf[1024];
	if (! wlist)
		return ;
	for (i = 0; i < strlen(wlist); i ++)
	{
		if (wlist[i] == '\n')
		{
			LOG_NORMAL_INFO("whost: %s\n", buf);
			speed_limit_whost_to_wip(buf);
			offset = 0;
		}
		else
		{
			buf[offset ++] = wlist[i];
			buf[offset] = 0;
		}
	}

	//-1��-1��ʾֱ�Ӷ�ȡ��һ�ε�����ֵ
	speed_limit_set_rate(SET_LAST_SPEED, SET_LAST_SPEED);
}

void *speed_limit_set_wlist_call(void *arg)
{
	pthread_detach(pthread_self());
	if (! arg)
		return NULL;
	pthread_mutex_lock(&tc_limit_lock);
	speed_limit_set_wlist(arg);
	free (arg);
	arg = NULL;
	pthread_mutex_unlock(&tc_limit_lock);

	return NULL;
}

int speed_limit_set_wlist_in_thread(char *wlist)
{
	pthread_t thread;
	char *arg;
	arg = (char *)calloc(1, strlen(wlist) + 1);
	if (! arg)
	{
		return -1;
	}
	memcpy(arg, wlist, strlen(wlist));
	int ret = pthread_create(&thread, NULL, speed_limit_set_wlist_call, arg);
	if (ret != 0)
	{
		free (arg);
		arg = NULL;
	}
	return ret;
}

void *speed_limit_set_rate_call(void *arg)
{
	pthread_detach(pthread_self());
	if (! arg)
		return NULL;
	pthread_mutex_lock(&tc_limit_lock);
	int upspeed = ((int *)arg)[0];
	int downspeed = ((int *)arg)[1];
	speed_limit_set_rate(upspeed, downspeed);
	free (arg);
	arg = NULL;
	pthread_mutex_unlock(&tc_limit_lock);

	return NULL;
}

int speed_limit_set_rate_in_thread(int up_speed, int down_speed)
{
	pthread_t thread;
	int *arg;
	arg = (int *)calloc(1, sizeof(int) * 2);
	if (! arg)
	{
		return -1;
	}
	arg[0] = up_speed;
	arg[1] = down_speed;
	int ret = pthread_create(&thread, NULL, speed_limit_set_rate_call, arg);
	if (ret != 0)
	{
		free (arg);
		arg = NULL;
	}
	return ret;
}

//����ԭ���Ľӿ�, up < 0 ����dws < 0��ʾֱ�Ӷ�ȡ��һ�ε��ٶ�ֵ
int qos_set_rate_limit_in_thread(int up_speed, int down_speed)
{
	return 0;
	return speed_limit_set_rate_in_thread(up_speed, down_speed);
}

void *qos_stop_rate_limit(void *arg)
{
	pthread_detach(pthread_self());

	pthread_mutex_lock(&tc_limit_lock);
	fw_tc_stop();

	fw_tc_del_redirect_to_vir_netdev_rule();
	fw_vir_netdev_destroy();

	set_upspeed_value(SET_FULL_SPEED);
	set_downspeed_value(SET_FULL_SPEED);
	pthread_mutex_unlock(&tc_limit_lock);

	return NULL;
}

//����ԭ���Ľӿ�, up < 0 ����dws < 0��ʾֱ�Ӷ�ȡ��һ�ε��ٶ�ֵ
int qos_stop_rate_limit_in_thread()
{
	pthread_t tdp;
	int ret = pthread_create(&tdp, NULL, qos_stop_rate_limit, NULL);
	return ret;
}

void qos_speed_limit_init()
{
	//ͣ������
	qos_stop_rate_limit_in_thread();
	//�����ʼ��
	speed_limit_wip_file_init();
	//��������߳�
	//create_net_dev_monitor_thread();
	speed_limit_set_rate(SET_LAST_SPEED, SET_LAST_SPEED);
}

