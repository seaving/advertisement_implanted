#ifndef __DEV_REG_H__
#define __DEV_REG_H__

int save_devno(char *devNo);
int read_devno(char *devNo);

#endif


