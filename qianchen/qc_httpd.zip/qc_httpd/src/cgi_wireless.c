#include "includes.h"

#define WIRELESS_24G	0
#define WIRELESS_5G		1

int _get_wireless_info(int witch, char *data_buf)
{
	int wireless_switch = get_wifi_disabled(witch);

	char channel[10] = {0};
	get_wifi_channel(witch, channel);

	char htmode[10] = {0};
	get_wifi_htmode(witch, htmode);

	int txpower = get_wifi_txpower(witch);

	int wireless_hidden = get_wifi_hidden(witch);

	char ssid[SSID_LEN + 1] = {0};
	get_wifi_ssid(witch, ssid);

	int password_switch = 0;
	char encryption[33] = {0};
	get_wifi_encryption(witch, encryption);
	if (strcmp(encryption, "none") == 0)
		password_switch = 0;
	else
		password_switch = 1;

	char wireless_password[WIFI_PASSWD_LEN + 1] = {0};
	get_wifi_key(witch, wireless_password);

	sprintf(data_buf, "{\"wireless_switch\":\"%d\",\"channel\":\"%s\",\"htmode\":\"%s\",\"txpower\":\"%d\",\"wireless_hidden\":\"%d\",\"ssid\":\"%s\",\"password_switch\":\"%d\",\"wireless_password\":\"%s\"}",
				wireless_switch, channel, htmode, txpower, wireless_hidden, ssid, password_switch, wireless_password);

	return 0;
}

int get_wireless_info(int num, char *hwmode, char *data_buf)
{
	if (hwmode && strlen(hwmode) <= 0)
		return -1;

	if (strchr(hwmode, 'a'))
	{
		//5G
		_get_wireless_info(num, data_buf);
		return 5;
	}
	else
	{
		//2G
		_get_wireless_info(num, data_buf);
		return 2;
	}

	return 0;
}

int cgi_get_wireless_info(struct evhttp_request *req, const t_http_server *http_server)
{
	//��ɨ�������豸
	char hwmode[2][20];
	memset(hwmode, 0, 40);
	get_wifi_hwmode(0, hwmode[0]);
	get_wifi_hwmode(1, hwmode[1]);

	LOG_WARN_INFO("0: %s, 1: %s\n", hwmode[0], hwmode[1]);

	char data[512] = {0};
	char data0[512] = {0};
	int fre = get_wireless_info(0, hwmode[0], data0);
	if (fre == 5)
	{
		sprintf(data, ",\"5g\":%s", data0);
	}
	else if (fre == 2)
	{
		sprintf(data, ",\"2g\":%s", data0);
	}

	char data1[512] = {0};
	int fre1 = get_wireless_info(1, hwmode[1], data1);
	if (fre1 == 5)
	{
		json_object *my_object = json_object_new_object();
		if (! my_object) return -1;

		char json_string[1048] = {0};
		snprintf(json_string, 1048, "%s%s", data1, data);
		json_object_object_add(my_object, "5g", json_object_new_string(json_string));
		LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));

		int ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
		json_object_put(my_object);
		
		return ret;
	}
	else if (fre1 == 2)
	{
		json_object *my_object = json_object_new_object();
		if (! my_object) return -1;

		char json_string[1048] = {0};
		snprintf(json_string, 1048, "%s%s", data1, data);
		json_object_object_add(my_object, "2g", json_object_new_string(json_string));
		LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));

		int ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
		json_object_put(my_object);
		
		return ret;
	}
	else
	{
		json_object *my_object = json_object_new_object();
		if (! my_object) return -1;

		char json_key[1048] = {0};
		snprintf(json_key, 1048, "%dg", fre);
		json_object_object_add(my_object, json_key, json_object_new_string(data0));
		LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));

		int ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
		json_object_put(my_object);
		
		return ret;
	}
	
	return -1;
}

int cgi_set_wireless(struct evhttp_request *req, const t_http_server *http_server)
{
	char *type = evhttp_get_post_parm(req, 				"type");
	char *wireless_switch = evhttp_get_post_parm(req, 	"wireless_switch");
	char *channel = evhttp_get_post_parm(req, 			"channel");
	char *htmode = evhttp_get_post_parm(req, 			"htmode");
	char *txpower = evhttp_get_post_parm(req, 			"txpower");	
	char *wireless_hidden = evhttp_get_post_parm(req, 	"wireless_hidden");
	char *ssid = evhttp_get_post_parm(req, 				"ssid");
	char *password_switch = evhttp_get_post_parm(req, 	"password_switch");
	char *wireless_password = evhttp_get_post_parm(req, "wireless_password");

	if (! type
	|| ! wireless_switch
	|| ! channel
	|| ! htmode
	|| ! txpower
	|| ! wireless_hidden
	|| ! ssid
	|| ! password_switch
	|| ! wireless_password) goto err;

	int witch = 0;
	if (strcmp(type, "2g") == 0)
	{
		char hwmode[2][20];
		memset(hwmode, 0, 40);
		get_wifi_hwmode(0, hwmode[0]);
		get_wifi_hwmode(1, hwmode[1]);
		if (! strchr(hwmode[0], 'a'))
		{
			//2g
			witch = 0;
		}
		else if (! strchr(hwmode[1], 'a'))
		{
			//2g
			witch = 1;
		}
		else
		{
			LOG_ERROR_INFO("can't find 2g device!\n");
			return -1;
		}
	}

	if (strcmp(type, "5g") == 0)
	{
		char hwmode[2][20];
		memset(hwmode, 0, 40);
		get_wifi_hwmode(0, hwmode[0]);
		get_wifi_hwmode(1, hwmode[1]);
		if (strchr(hwmode[0], 'a'))
		{
			//5g
			witch = 0;
		}
		else if (strchr(hwmode[1], 'a'))
		{
			//5g
			witch = 1;
		}
		else
		{
			LOG_ERROR_INFO("can't find 5g device!\n");
			return -1;
		}
	}

	if (atoi(txpower) > 30 
	|| atoi(txpower) <= 0 
	|| (atoi(wireless_switch) != 0 && atoi(wireless_switch) != 1)) goto err;
	
	if (((atoi(wireless_hidden) != 0) && (atoi(wireless_hidden) != 1))
	|| ((atoi(password_switch) != 0) && (atoi(password_switch) != 1))) goto err;

	set_wifi_hidden(witch, atoi(wireless_hidden));
	set_wifi_ssid(witch, ssid);
	
	if (atoi(password_switch))
		set_wifi_encryption(witch, "psk2");
	else
		set_wifi_encryption(witch, "none");

	set_wifi_key(witch, wireless_password);

	//HT40M+ֻ��֧��1-7ͨ��
	//HT40M-ֻ��֧��5-13ͨ��
	//HT20M֧��1-13ͨ��
	/*
	11n������Ƶ��ģʽ��HT(High Throughput)20��HT40��
	HT20�ǳ��ڼ����Կ��ǣ����磬һ�������ڴ���11b/g�źţ���ôΪ�˾������ٶ����ǵĸ��ţ���Ҫ�趨ΪHT20���Լ���Ƶ�����ص���
	HT40�ǳ��ڸ����ܿ��ǣ�HT40�൱������HT20������һ��������һ���Ǹ������ŵ�����beacon���ĺͲ������ݱ��ģ����ŵ������������ġ�
	����HT40�������Ϊ40M����һ������ʽ���߸���������ò�Ҫ��2.4GHzʹ�ã������5GHzʹ�á���2.4Gʹ��HT40������Чͨ����3~13�����ص���ֻ��3��11.
	*/
	if (strcmp(type, "2g") == 0 && strcmp(htmode, "HT20") == 0
	&& 1 <= atoi(channel) && atoi(channel) <= 13)
	{
		set_wifi_channel(witch, channel);		
		set_wifi_htmode(witch, htmode);
	}
	
	if (strcmp(type, "5g") == 0 && strcmp(htmode, "HT20") == 0
	&& 149 <= atoi(channel) && atoi(channel) < 165)
	{
		set_wifi_channel(witch, channel);		
		set_wifi_htmode(witch, htmode);
	}

	if (strcmp(type, "2g") == 0 
	&& (strcmp(htmode, "HT40+") == 0 || strcmp(htmode, "HT40") == 0)
	&& 1 <= atoi(channel) && atoi(channel) <= 7)
	{
		set_wifi_channel(witch, channel);		
		set_wifi_htmode(witch, htmode);
	}	

	if (strcmp(type, "2g") == 0 
	&& strcmp(htmode, "HT40-") == 0
	&& 5 <= atoi(channel) && atoi(channel) <= 13)
	{
		set_wifi_channel(witch, channel);		
		set_wifi_htmode(witch, htmode);
	}

	if (strcmp(type, "5g") == 0 
	&& (strcmp(htmode, "HT40+") == 0 || strcmp(htmode, "HT40") == 0)
	&& 149 <= atoi(channel) && atoi(channel) < 165)
	{
		set_wifi_channel(witch, channel);		
		set_wifi_htmode(witch, htmode);
	}

	if (strcmp(type, "5g") == 0 && (strcmp(htmode, "VHT80") == 0) 
	&& 149 <= atoi(channel) && atoi(channel) < 165)
	{
		set_wifi_channel(witch, channel);		
		set_wifi_htmode(witch, htmode);
	}

	set_wifi_disabled(witch, atoi(wireless_switch));
	set_wifi_txpower(witch, atoi(txpower));

	uci_commit();
	restart_network();

	evhttp_send_reply (req, 200, "OK", NULL);

	if (type) 				free(type);
	if (wireless_switch) 	free(wireless_switch);
	if (channel) 			free(channel);
	if (htmode) 			free(htmode);
	if (txpower) 			free(txpower);
	if (wireless_hidden) 	free(wireless_hidden);
	if (ssid) 				free(ssid);
	if (password_switch) 	free(password_switch);
	if (wireless_password) 	free(wireless_password);
	return 0;

err:
	if (type) 				free(type);
	if (wireless_switch) 	free(wireless_switch);
	if (channel) 			free(channel);
	if (htmode) 			free(htmode);
	if (txpower) 			free(txpower);
	if (wireless_hidden) 	free(wireless_hidden);
	if (ssid) 				free(ssid);
	if (password_switch) 	free(password_switch);
	if (wireless_password) 	free(wireless_password);
	return -1;
}


