#include "includes.h"

#define CMD_DHCP_LEASETIME_GET	"uci get dhcp.lan.leasetime"
#define CMD_DHCP_LEASETIME_SET	"uci set dhcp.lan.leasetime"

#define CMD_DHCP_POOL_MIN_GET	"uci get dhcp.lan.start"
#define CMD_DHCP_POOL_MAX_GET	"uci get dhcp.lan.limit"

#define CMD_DHCP_POOL_MIN_SET	"uci set dhcp.lan.start"
#define CMD_DHCP_POOL_MAX_SET	"uci set dhcp.lan.limit"

//---------------------------------------------------------
//����
void _get_dhcp_leasetime_call_(char *buf, void *leasetime)
{
	if (leasetime && buf)
	{
		memcpy((char *)leasetime, buf, strlen(buf));
	}
}

int get_dhcp_leasetime()
{
	char leasetime[10] = {0};
	
	if (popen_cmd(CMD_DHCP_LEASETIME_GET, _get_dhcp_leasetime_call_, leasetime) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("leasetime: %s\n", leasetime);

	char *p = strchr(leasetime, 'h');
	if (p)
		*p = 0;

	return atoi(leasetime);
}

int set_dhcp_leasetime(unsigned char leasetime)
{
	if (leasetime <= 0 && leasetime > 24)
		return -1;
	
	char cmd[255];
	EXECUTE_CMD(cmd, "%s=%d", CMD_DHCP_LEASETIME_SET, leasetime);
	return 0;
}

//----------------------------------------------
//��ȡdhcp�б�
void _get_dhcp_list_call_(char *buf, void *list)
{
	if (list && buf)
	{
		memcpy((char *)(list + strlen((char *)list)), buf, strlen(buf));
		memcpy((char *)(list + strlen((char *)list)), "\r\n", strlen("\r\n"));
	}
}

int get_dhcp_list(char *list, int page_num, int page_count)
{
	char cmd[255] = {0};
	sprintf(cmd, "cat /tmp/dhcp.leases | head -n %d | tail -n %d | awk -F \" \" '{print $1 \" \" $2 \" \" $3 \" \" $4}'", page_num * page_count, page_count);
	
	if (popen_cmd(cmd, _get_dhcp_list_call_, list) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("list: %s\n", list);

	return 0;
}

void _get_dhcp_list_cnt_call_(char *buf, void *cnt)
{
	if (cnt && buf)
	{
		memcpy((char *)cnt, buf, strlen(buf));
	}
}

int get_dhcp_list_cnt()
{
	char cnt[15] = {0};
	if (popen_cmd("cat /tmp/dhcp.leases | wc -l", _get_dhcp_list_cnt_call_, cnt) < 0)
	{
		return -1;
	}
	
	return atoi(cnt);
}
//---------------------------------------------
//ip pool
void _get_dhcp_ippool_call_(char *buf, void *val)
{
	if (val && buf)
	{
		memcpy((char *)val, buf, strlen(buf));
	}
}

int get_dhcp_ippool_min()
{
	char min[10] = {0};
	if (popen_cmd(CMD_DHCP_POOL_MIN_GET, _get_dhcp_ippool_call_, min) < 0)
	{
		return -1;
	}

	return atoi(min);
}

int get_dhcp_ippool_max()
{
	char max[10] = {0};
	if (popen_cmd(CMD_DHCP_POOL_MAX_GET, _get_dhcp_ippool_call_, max) < 0)
	{
		return -1;
	}

	return atoi(max);
}

int set_dhcp_ippool(int min, int max)
{
	if (min > max)
		return -1;
	if (min > 255 || max > 255 || min < 0 || max < 0)
		return -1;
	char cmd[255];
	EXECUTE_CMD(cmd, "%s=%d", CMD_DHCP_POOL_MIN_SET, min);
	EXECUTE_CMD(cmd, "%s=%d", CMD_DHCP_POOL_MAX_SET, max);	
	return 0;
}




