#ifndef __CGI_NETWORK_H__
#define __CGI_NETWORK_H__

#include "common.h"
#include "evhttp_server.h"

int cgi_network_set_lan_ipaddr(struct evhttp_request *req, const t_http_server *http_server);

int cgi_get_network_info(struct evhttp_request *req, const t_http_server *http_server);
int cgi_set_network(struct evhttp_request *req, const t_http_server *http_server);


#endif



