#ifndef __PASSWD_H__
#define __PASSWD_H__



int get_passwd(char *passwd);
int set_passwd(char *passwd);

#endif
