#ifndef __CGI_CONFIG_H__
#define __CGI_CONFIG_H__

#include "cgi.h"
#include "cgi_network.h"
#include "cgi_system.h"
#include "cgi_dhcp.h"
#include "cgi_wireless.h"

cgi_t cgi[] = {
	{"system.html?api=get_system_info", cgi_get_system_info},
	{"network.html?api=get_wan_info", cgi_get_network_info},
	{"network.html?api=set_network_dhcp", cgi_set_network},
	{"network.html?api=set_network_pppoe", cgi_set_network},
	{"dhcp.html?api=get_dhcp_list", cgi_get_dhcp_list},
	{"dhcp.html?api=get_dhcp_info", cgi_get_dhcp_info},
	{"dhcp.html?api=set_dhcp", cgi_set_dhcp},
	{"wireless.html?api=get_wireless_info", cgi_get_wireless_info},
	{"wireless.html?api=set_wireless", cgi_set_wireless},
	{"devreg.html?api=dev_reg", cgi_dev_reg},
	{"devreg.html?api=dev_reg_result", cgi_dev_reg_result},
	{"reboot.html?api=reboot", cgi_reboot},
	{"setpwd.html?api=modify_pwd", cgi_modify_pwd},
	{"resetpwd.html?api=set_pwd", cgi_reset_pwd},
	{"index.html?api=logout", cgi_logout},
	{NULL, NULL}
};


#endif


