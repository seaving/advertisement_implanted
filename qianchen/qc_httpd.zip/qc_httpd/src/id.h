#ifndef __ID_H__
#define __ID_H__

#define ID             "default000000"

#define PLATFORMS      "x86"

#define MODULE_NAME	 "qchttpd"


#endif
