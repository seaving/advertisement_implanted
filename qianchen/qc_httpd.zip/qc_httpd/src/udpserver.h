#ifndef __UDP_SERVER_H__
#define __UDP_SERVER_H__


#define RECV_SIZE_MAX	512

int create_udp_server_thread();


#endif

