#ifndef __AC_H__
#define __AC_H__

#include "common.h"

int ac_process(int ufd, struct sockaddr_in *from, char *buf, int len);



#endif


