
#include "includes.h"

//����lan��ip��ַ
int cgi_network_set_lan_ipaddr(struct evhttp_request *req, const t_http_server *http_server)
{
	char *ipaddr = evhttp_get_post_parm(req, "ipaddr");
	if (! ipaddr) return -1;
	
	set_lan_ipaddr(ipaddr);
	uci_commit();
	restart_network();
	evhttp_send_reply(req, 200, "OK", NULL);
	return 0;
}

//��ȡwan����
int cgi_get_network_info(struct evhttp_request *req, const t_http_server *http_server)
{
	char proto[10] = {0};
	if (get_wan_proto(proto) < 0)
		return -1;
		
	if (strcmp(proto, "pppoe") && strcmp(proto, "dhcp"))
		return -1;
	
	char ip[32] = {0};
	if (get_dev_ip(ip, get_netdev_wan_name()) < 0)
	{
		//sprintf(ip, "0.0.0.0");
	}
	char mask[32] = {0};
	if (get_dev_mask(mask, get_netdev_wan_name()) < 0)
	{
		//sprintf(mask, "0.0.0.0");
	}
	char gw[32] = {0};
	if (get_gateway(gw) < 0)
	{
		//sprintf(gw, "0.0.0.0");
	}
	char dns[32] = {0};
	if (get_dns(dns, 1) < 0)
	{
		//sprintf(dns, "0.0.0.0");
	}
	char dns_2[32] = {0};
	if (get_dns(dns_2, 2) < 0)
	{
		//sprintf(dns_2, "0.0.0.0");
	}

	if (strcmp(proto, "pppoe") == 0)
	{
		char username[33] = {0};
		if (get_wan_username(username) < 0)
		{
			//sprintf(username, "no user");
		}
		char password[33] = {0};
		if (get_wan_password(password) < 0)
		{
			//sprintf(username, "no password");
		}
		
		json_object *my_object = json_object_new_object();
		if (! my_object) return -1;
		json_object_object_add(my_object, "proto", 		json_object_new_string(proto));
		json_object_object_add(my_object, "username",	json_object_new_string(username));
		json_object_object_add(my_object, "password",	json_object_new_string(password));
		json_object_object_add(my_object, "ip",			json_object_new_string(ip));
		json_object_object_add(my_object, "gateway",	json_object_new_string(gw));
		json_object_object_add(my_object, "mask",		json_object_new_string(mask));
		json_object_object_add(my_object, "dns_first",	json_object_new_string(dns));
		json_object_object_add(my_object, "dns_second",	json_object_new_string(dns_2));
		LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));
		int ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
		json_object_put(my_object);
		
		return ret;
	}
	else if (strcmp(proto, "static") == 0)
	{
		return -1;
	}
	else if (strcmp(proto, "dhcp") == 0)
	{
		json_object *my_object = json_object_new_object();
		if (! my_object) return -1;
		json_object_object_add(my_object, "proto", 		json_object_new_string(proto));
		json_object_object_add(my_object, "ip",			json_object_new_string(ip));
		json_object_object_add(my_object, "gateway",	json_object_new_string(gw));
		json_object_object_add(my_object, "mask",		json_object_new_string(mask));
		json_object_object_add(my_object, "dns_first",	json_object_new_string(dns));
		json_object_object_add(my_object, "dns_second",	json_object_new_string(dns_2));
		LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));
		int ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
		json_object_put(my_object);
		
		return ret;
	}
	
	return -1;
}

//����wan����
int cgi_set_network(struct evhttp_request *req, const t_http_server *http_server)
{
	char *username = NULL;
	char *password = NULL;
	char *proto = evhttp_get_post_parm(req, "proto");
	if (strcmp(proto, "pppoe") == 0)
	{
		username = evhttp_get_post_parm(req, "username");
		password = evhttp_get_post_parm(req, "password");
		if (! username || ! password) goto err;
		
		set_wan_proto("pppoe");
		set_wan_username(username);
		set_wan_password(password);
		uci_commit();
		restart_network();
	}
	else if (strcmp(proto, "static") == 0)
	{
		goto err;
	}
	else if (strcmp(proto, "dhcp") == 0)
	{
		set_wan_proto(proto);
		uci_commit();
		restart_network();
	}

	evhttp_send_reply(req, 200, "OK", NULL);

	if (username) free(username);
	if (password) free(password);
	if (proto) free(proto);
	return 0;
	
err:
	if (username) free(username);
	if (password) free(password);
	if (proto) free(proto);

	return -1;
}



