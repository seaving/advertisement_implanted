#include "includes.h"

bool getRequestParma(char *data, char *parma_name, char *value, int value_size)
{
	char *p = straddr(data, parma_name);
	if (p)
	{
		p += strlen(parma_name);
		if (*p == '=')
		{
			p ++;

			int i, j = 0;
			for (i = 0; i < strlen(p); i ++)
			{
				if (p[i] == ' '
				|| p[i] == '\r'
				|| p[i] == '\n'
				|| p[i] == '&')
				{
					break;
				}
				
				value[j ++] = p[i];
				value[j] = 0;

				if (j >= value_size - 1)
					break;
			}
			return true;
		}
	}

	return false;
}

int url_add_param(char *param_name, char *param_arg, char *addr)
{
	int len, bufsize;
	char *pjs = addr;
	len = strlen(param_name);
	memcpy(pjs, param_name, len);
	pjs += len;
	len = strlen(param_arg);
	bufsize = len * 4 + 1;
	char code[bufsize];
	len = url_encode((unsigned char *)param_arg, len, (unsigned char *)code, bufsize);
	memcpy(pjs, code, len);
	pjs += len;
	return pjs - addr;
}



