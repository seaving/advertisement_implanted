#ifndef __CGI_DEV_REG_H__
#define __CGI_DEV_REG_H__

#include "common.h"
#include "evhttp_server.h"

int cgi_dev_reg(struct evhttp_request *req, const t_http_server *http_server);

int cgi_dev_reg_result(struct evhttp_request *req, const t_http_server *http_server);

#endif

