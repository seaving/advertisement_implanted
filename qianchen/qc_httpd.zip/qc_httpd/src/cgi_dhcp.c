
#include "includes.h"

int cgi_get_dhcp_list(struct evhttp_request *req, const t_http_server *http_server)
{
	char *page_num = evhttp_get_parm(req, "page_num");
	if (! page_num)
		return -1;
		
	int page_num_tmp = atoi(page_num);
	if (page_num_tmp <= 0) page_num_tmp = 1;
	free(page_num);
	
	int page_count = 5;
	
	char list[1024] = {0};
	get_dhcp_list(list, page_num_tmp, page_count);

	int cnt = get_dhcp_list_cnt();
	if (cnt <= 0) cnt = 0;
		
	int total_page = cnt / page_count;
	if (cnt % page_count) total_page ++;

	if (! cnt) total_page = 1;
	
	if (page_num_tmp > total_page)
		page_num_tmp = total_page;

	json_object *my_object = json_object_new_object();
	if (! my_object) return -1;
	json_object_object_add(my_object, "total_page", json_object_new_int(total_page));
	json_object_object_add(my_object, "list_cnt", 			json_object_new_int(cnt));
	json_object_object_add(my_object, "page_count", json_object_new_int(page_count));
	json_object_object_add(my_object, "page_num", 		json_object_new_int(page_num_tmp));
	json_object_object_add(my_object, "list", 		json_object_new_string(list));
	LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));
	int ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
	json_object_put(my_object);

	return ret;
}

//��ȡdhcp����Ϣ
int cgi_get_dhcp_info(struct evhttp_request *req, const t_http_server *http_server)
{
	char gateway[32] = {0};
	get_lan_ipaddr(gateway);
	char mask[32] = {0};
	get_lan_mask(mask);
	int pool_min = get_dhcp_ippool_min();
	if (pool_min < 0)
	{
		pool_min = 0;
	}
	
	int pool_max = get_dhcp_ippool_max();
	if (pool_max < 0)
	{
		pool_max = 0;
	}
	
	int leasetime = get_dhcp_leasetime();
	if (leasetime < 0)
	{
		leasetime = 0;
	}

	int dhcp_list_cnt = get_dhcp_list_cnt();

	json_object *my_object = json_object_new_object();
	if (! my_object) return -1;
	json_object_object_add(my_object, "dhcp_list_cnt", json_object_new_int(dhcp_list_cnt));
	json_object_object_add(my_object, "leasetime", json_object_new_int(leasetime));
	json_object_object_add(my_object, "gateway", 	json_object_new_string(gateway));
	json_object_object_add(my_object, "mask", 		json_object_new_string(mask));
	json_object_object_add(my_object, "pool_min", 		json_object_new_int(pool_min));
	json_object_object_add(my_object, "pool_max", 		json_object_new_int(pool_max));
	json_object_object_add(my_object, "pool_count", json_object_new_int(pool_max - pool_min));
	LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));

	int ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
	json_object_put(my_object);

	return ret;
}

int cgi_set_dhcp(struct evhttp_request *req, const t_http_server *http_server)
{
	char lan_ip[32] = {0};
	get_dev_ip(lan_ip, get_netdev_lan_name());
	char *gateway = evhttp_get_post_parm(req, 		"gateway");
	char *mask = evhttp_get_post_parm(req, 			"mask");
	char *ip_pool_min = evhttp_get_post_parm(req, 	"ip_pool_min");
	char *ip_pool_max = evhttp_get_post_parm(req, 	"ip_pool_max");
	char *leasetime = evhttp_get_post_parm(req, 	"leasetime");
	
	if (! gateway 
	|| ! mask 
	|| ! ip_pool_min 
	|| ! ip_pool_max 
	|| ! leasetime) goto err;
	
	if (atoi(ip_pool_min) < 0 
	|| atoi(ip_pool_min) > 255
	|| atoi(ip_pool_max) < 0 
	|| atoi(ip_pool_max) > 255
	|| atoi(ip_pool_min) > atoi(ip_pool_max) 
	|| atoi(leasetime) <= 0
	|| atoi(leasetime) > 24 
	|| ! is_ip_str(gateway) 
	|| ! is_ip_str(mask)) goto err;
	
	set_dhcp_ippool(atoi(ip_pool_min), atoi(ip_pool_max));
	set_dhcp_leasetime((unsigned char)atoi(leasetime));
	set_lan_ipaddr(gateway);
	set_lan_mask(mask);

	uci_commit();
	restart_network();
	
	if (strcmp(gateway, lan_ip))
	{
		msg_send(NULL, 0, FRAME_MODULE_QCHTTPD, FRAME_MODULE_FW_SET, FRAME_CMD_FW_RESET);
		msg_send(NULL, 0, FRAME_MODULE_QCHTTPD, FRAME_MODULE_APCTRL, FRAME_CMD_GW_ADDR);
	}

	evhttp_send_reply (req, 200, "OK", NULL);

	if (gateway) 	free(gateway);
	if (mask) 		free(mask);
	if (ip_pool_min) free(ip_pool_min);
	if (ip_pool_max) free(ip_pool_max);
	if (leasetime) 	free(leasetime);
	
	return 0;
err:
	if (gateway) 	free(gateway);
	if (mask) 		free(mask);
	if (ip_pool_min) free(ip_pool_min);
	if (ip_pool_max) free(ip_pool_max);
	if (leasetime) 	free(leasetime);
	return -1;
}

