#include "includes.h"

#define PASSWD_FILE		"/etc/app/passwd.txt"

int get_passwd(char *passwd)
{
	int fd = open_file(PASSWD_FILE);
	if (fd < 0)
	{
		passwd[0] = '\0';
		return -1;
	}

	int ret = read(fd, passwd, 16);
	if (ret <= 0)
	{
		LOG_PERROR_INFO("read error.");
		close(fd);
		return -1;
	}

	close(fd);

	char *p = strchr(passwd, '\r');
	if (p)
		*p = 0;
	p = strchr(passwd, '\n');
	if (p)
		*p = 0;

	return ret;
}

int set_passwd(char *passwd)
{
	create_file(PASSWD_FILE);
	int fd = open_file(PASSWD_FILE);
	if (fd < 0)
	{
		return -1;
	}

	write(fd, passwd, strlen(passwd));
	
	close(fd);
	
	return 0;
}




