#include "includes.h"

int cgi_modify_pwd(struct evhttp_request *req, const t_http_server *http_server)
{
	char *newPwd = evhttp_get_post_parm(req, "newPwd");
	char *repeat = evhttp_get_post_parm(req, "repeatNewPwd");
	if (! newPwd || ! repeat) goto err;
	
	int ret = -1;
	if (strcmp(newPwd, repeat) == 0)
	{
		LOG_NORMAL_INFO("password set success .\n");
		set_passwd(newPwd);
		
		json_object *my_object = json_object_new_object();
		if (! my_object) return -1;
		json_object_object_add(my_object, "res", json_object_new_string("success"));
		LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));
		ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
		json_object_put(my_object);
	}
	else
	{
		json_object *my_object = json_object_new_object();
		if (! my_object) return -1;
		json_object_object_add(my_object, "res", json_object_new_string("error"));
		LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));
		ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
		json_object_put(my_object);
	}
	
	if (newPwd) free(newPwd);
	if (repeat) free(repeat);
	return ret;
err:
	if (newPwd) free(newPwd);
	if (repeat) free(repeat);
	return -1;
}

int cgi_reset_pwd(struct evhttp_request *req, const t_http_server *http_server)
{
	char *oldPwd = evhttp_get_post_parm(req, "oldPwd");
	char *newPwd = evhttp_get_post_parm(req, "newPwd");
	char *repeat = evhttp_get_post_parm(req, "repeatNewPwd");
	if (! newPwd || ! repeat || ! oldPwd) goto err;

	char login_pwd[17] = {0};
	get_passwd(login_pwd);
	
	int ret = -1;
	if (strcmp(oldPwd, login_pwd) == 0
	&& strcmp(newPwd, repeat) == 0)
	{
		LOG_NORMAL_INFO("password reset success .\n");
		set_passwd(newPwd);
		json_object *my_object = json_object_new_object();
		if (! my_object) return -1;
		json_object_object_add(my_object, "res", json_object_new_string("success"));
		LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));
		ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
		json_object_put(my_object);
	}
	else
	{
		json_object *my_object = json_object_new_object();
		if (! my_object) return -1;
		json_object_object_add(my_object, "res", json_object_new_string("error"));
		LOG_HL_INFO("JSON -->: %s\n", json_object_to_json_string(my_object));
		ret = evhttpd_send_200_response(req, NULL, json_object_to_json_string(my_object));
		json_object_put(my_object);
	}
	
	if (oldPwd) free(oldPwd);
	if (newPwd) free(newPwd);
	if (repeat) free(repeat);
	return ret;

err:
	if (oldPwd) free(oldPwd);
	if (newPwd) free(newPwd);
	if (repeat) free(repeat);
	return -1;
}


