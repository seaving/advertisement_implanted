#include "includes.h"

int cgi_dev_reg(struct evhttp_request *req, const t_http_server *http_server)
{
	char fwv[64] = {0};
	if (get_firmware_version(fwv) < 0)
		return -1;

	char gw[32] = {0};
	get_lan_ipaddr(gw);

	char router_mac[32] = {0};
	get_local_mac(router_mac, get_netdev_wan_name());

	char md5[33] = {0};
	char tmp[strlen(fwv) + strlen(router_mac) + TOKEN_KEY_LEN + 1];
	sprintf(tmp, "%s%s", router_mac, fwv);
	CalMd5(tmp, strlen(tmp), md5);

	char back_url[255] = {0};
	snprintf(back_url, 254, "http://%s:%d/html/devreg.html?api=dev_reg_result", gw, WEB_SERVER_PORT);

	char redirect_url[520] = {0};
	sprintf(redirect_url, REG_URL);
	char *p = redirect_url + strlen(redirect_url);
	int offset = url_add_param("?mac=", router_mac, p);
	p += offset;
	offset = url_add_param("&fwv=", fwv, p);
	p += offset;
	offset = url_add_param("&backUrl=", back_url, p);
	p += offset;
	offset = url_add_param("&token=", md5, p);
	p += offset;

	LOG_NORMAL_INFO("redirect_url: %s\n", redirect_url);
	
	evhttp_gw_reply_302_redirect(req, redirect_url);

	return 0;
}

int cgi_dev_reg_result(struct evhttp_request *req, const t_http_server *http_server)
{
	char *devNo = evhttp_get_parm(req, "devNo");
	char *token = evhttp_get_parm(req, "token");
	char *backUrl = evhttp_get_parm(req, "backUrl");
	char buf[255 + TOKEN_KEY_LEN] = {0};

	char route_mac[33] = {0};
	get_local_mac(route_mac, get_netdev_wan_name());

	if (! devNo || ! token || ! backUrl) goto err;

	int len = strlen(devNo) + strlen(route_mac);
	if (len > 64) goto err;

	sprintf(buf, "%s%s", devNo, route_mac);
	char md5[33] = {0};
	CalMd5(buf, strlen(buf), md5);
	
	if (strcmp(md5, token))
	{
		LOG_ERROR_INFO("md5 error! md5=%s, token=%s\n", md5, token);
		goto err;
	}

	snprintf(buf, 255, "?devNo=%s&mac=%s&token=%s", devNo, route_mac, token);

	if (save_devno(devNo) < 0) goto err;
	
	msg_send(devNo, strlen(devNo), FRAME_MODULE_QCHTTPD, FRAME_MODULE_APCTRL, FRAME_CMD_SET_DEV_NO);
	msg_send(NULL, 0, FRAME_MODULE_QCHTTPD, FRAME_MODULE_INIT, FRAME_CMD_UPDATE);

	evhttp_gw_reply_302_redirect(req, buf);
	
	return 0;

err:
	if (devNo) free(devNo);
	if (token) free(token);
	if (backUrl) free(backUrl);
	return -1;
}


