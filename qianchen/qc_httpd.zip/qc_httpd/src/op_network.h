#ifndef __NETWORK_OP_H__
#define __NETWORK_OP_H__

int get_lan_ipaddr(char *ipaddr);
int set_lan_ipaddr(char *ipaddr);

int get_lan_mask(char *mask);
int set_lan_mask(char *mask);

int get_wan_proto(char *proto);
int set_wan_proto(char *proto);

int get_wan_username(char *username);
int set_wan_username(char *username);

int get_wan_password(char *password);
int set_wan_password(char *password);

int get_wan_ipadrr(char *ipadrr);
int set_wan_ipadrr(char *ipadrr);


#endif

