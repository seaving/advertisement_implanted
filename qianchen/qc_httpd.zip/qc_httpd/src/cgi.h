#ifndef __CGI_H__
#define __CGI_H__

#include "common.h"
#include "evhttp_server.h"

//uri: http����ͷ�� path
//context: post context
typedef int (*cgi_fun)(struct evhttp_request *req, const t_http_server *http_server);

typedef struct _cgi_
{
	char *map_name;
	cgi_fun fun;
} cgi_t;


int evhttp_cgi_service(struct evhttp_request *req, const t_http_server *http_server);


#endif

