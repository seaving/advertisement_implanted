#include "includes.h"

#define WIP_DIR		"/tmp/qos"
#define WIP_FILE	WIP_DIR"/wip.conf"

static int _wip_file_open(int mod)
{
    int fd = open(WIP_FILE, O_CREAT | O_RDWR | mod, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
    if(fd < 0)
    {
        return -1;
    }
    return fd;
}

static void _speed_limit_wip_file_close(int fd)
{
	if (fd > 0)
		close(fd);
}

static int _speed_limit_wip_file_open()
{
	return _wip_file_open(O_APPEND);
}

static int _speed_limit_wip_file_create()
{
	int ret = _wip_file_open(O_TRUNC);
	_speed_limit_wip_file_close(ret);
	return ret;
}

int speed_limit_wip_file_init()
{
	mkdir(WIP_DIR, 0777);
	return _speed_limit_wip_file_create();
}

static int _speed_limit_wip_file_size()  
{  
    int filesize = -1;  
    FILE *fp;
    fp = fopen(WIP_FILE, "r");
    if(fp == NULL)
        return filesize;
    fseek(fp, 0L, SEEK_END);
    filesize = ftell(fp);
    fclose(fp);
    return filesize;
}

int speed_limit_wip_file_write(char *wip)
{
	int fd = _speed_limit_wip_file_open();
	if (fd <= 0)
		return -1;
	char buf[64];
	sprintf(buf, "%s\n", wip);
	int ret = write(fd, buf, strlen(buf));
	if (ret != strlen(buf))
	{
		_speed_limit_wip_file_close(fd);
		return -1;
	}
	_speed_limit_wip_file_close(fd);
	return 0;
}

char* speed_limit_wip_file_read()
{
	int size = _speed_limit_wip_file_size();
	if (size <= 0)
	{
		return NULL;
	}

	FILE *pp = popen("cat " WIP_FILE " | sort -u", "r");
	if (! pp)
	{
		return NULL;
	}

	char *wip_buf = calloc(1, size + 1);
	if (! wip_buf)
		return NULL;
	
	int offset = 0;
	char buf[64] = {0};
	while (fgets(buf, sizeof(buf), pp) != NULL)
	{
		int len = strlen(buf);
		if (buf[len - 1] != '\n')
			buf[len ++] = '\n';
		//LOG_NORMAL_INFO("%s", buf);
		memcpy(wip_buf + offset, buf, len);
		offset += len;
		memset(buf, 0, sizeof(buf));
	}
	pclose(pp);
	pp = NULL;
	return wip_buf;
}

static int _speed_limit_whost_to_wip(char *hostname)
{
	struct addrinfo *answer, hint, *curr;
	char ipaddr[32] = {0};
	char *ipstr = ipaddr;
	struct sockaddr_in *addr;
	bzero(&hint, sizeof(hint));
	hint.ai_family = AF_INET;
	hint.ai_socktype = SOCK_STREAM;
	
	int ret = getaddrinfo(hostname, NULL, &hint, &answer);
	if (ret != 0)
	{
		LOG_NORMAL_INFO("[ %s ] getaddrinfo: %s", hostname, gai_strerror(ret));
		return -1;
	}
	for (curr = answer; curr != NULL; curr = curr->ai_next)
	{
		addr = (struct sockaddr_in *)curr->ai_addr;
		memset(ipstr, 0, 32);
		inet_ntop(AF_INET, &addr->sin_addr, ipstr, 16);
		LOG_NORMAL_INFO("%s --> %s", hostname, ipstr);
		speed_limit_wip_file_write(ipstr);
	}
	
	freeaddrinfo(answer);
	return 0;
}


int speed_limit_whost_to_wip(char *whost)
{
	_speed_limit_whost_to_wip(whost);
	return 0;
}

#if 0
int speed_limit_defalt_whost_to_ip()
{
	_speed_limit_whost_to_wip("www.manyoubao.com");
	_speed_limit_whost_to_wip("bsp.skyroam.com");
	_speed_limit_whost_to_wip("192.168.43.1");
	return 0;
}
#endif

