#include "includes.h"


void uci_commit()
{
	char cmd[32] = {0};
	EXECUTE_CMD(cmd, "uci commit");
}

void restart_network()
{
	return;
	
	//char cmd[32] = {0};
	//EXECUTE_CMD(cmd, "/etc/init.d/network restart");
}

