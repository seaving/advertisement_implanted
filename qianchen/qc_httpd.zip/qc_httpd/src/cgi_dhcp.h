
#ifndef __CGI_DHCP_H__
#define __CGI_DHCP_H__

#include "common.h"
#include "evhttp_server.h"

int cgi_get_dhcp_list(struct evhttp_request *req, const t_http_server *http_server);
int cgi_get_dhcp_info(struct evhttp_request *req, const t_http_server *http_server);

int cgi_set_dhcp(struct evhttp_request *req, const t_http_server *http_server);

#endif


