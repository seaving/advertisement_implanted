#include "includes.h"


#define CMD_NETWORK_LAN_IPADDR_GET	"uci get network.lan.ipaddr"
#define CMD_NETWORK_LAN_IPADDR_SET	"uci set network.lan.ipaddr"

#define CMD_NETWORK_LAN_MASK_GET	"uci get network.lan.netmask"
#define CMD_NETWORK_LAN_MASK_SET	"uci set network.lan.netmask"

#define CMD_NETWORK_WAN_PROTO_GET	"uci get network.wan.proto"
#define CMD_NETWORK_WAN_PROTO_SET	"uci set network.wan.proto"

#define CMD_NETWORK_WAN_USERNAME_GET	"uci get network.wan.username"
#define CMD_NETWORK_WAN_USERNAME_SET	"uci set network.wan.username"

#define CMD_NETWORK_WAN_PASSWORD_GET	"uci get network.wan.password"
#define CMD_NETWORK_WAN_PASSWORD_SET	"uci set network.wan.password"

#define CMD_NETWORK_WAN_IPADDR_GET	"uci get network.wan.ipaddr"
#define CMD_NETWORK_WAN_IPADDR_SET	"uci set network.wan.ipaddr"


//---------------------------------------------
//lan ipaddr
void _get_lan_ipaddr_call_(char *buf, void *ipaddr)
{
	if (ipaddr && buf)
	{
		memcpy((char *)ipaddr, buf, strlen(buf));
	}
}

int get_lan_ipaddr(char *ipaddr)
{
	if (popen_cmd(CMD_NETWORK_LAN_IPADDR_GET, _get_lan_ipaddr_call_, ipaddr) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("lan ipaddr: %s\n", ipaddr);

	return 0;
}

int set_lan_ipaddr(char *ipaddr)
{
	char cmd[255];
	EXECUTE_CMD(cmd, "%s=%s", CMD_NETWORK_LAN_IPADDR_SET, ipaddr);
	return 0;
}
//---------------------------------------------
//lan mask
void _get_lan_mask_call_(char *buf, void *mask)
{
	if (mask && buf)
	{
		memcpy((char *)mask, buf, strlen(buf));
	}
}

int get_lan_mask(char *mask)
{
	if (popen_cmd(CMD_NETWORK_LAN_MASK_GET, _get_lan_mask_call_, mask) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("lan mask: %s\n", mask);

	return 0;
}

int set_lan_mask(char *mask)
{
	char cmd[255];
	EXECUTE_CMD(cmd, "%s=%s", CMD_NETWORK_LAN_MASK_SET, mask);
	return 0;
}
//---------------------------------------------
//wan proto
void _get_wan_proto_call_(char *buf, void *proto)
{
	if (proto && buf)
	{
		memcpy((char *)proto, buf, strlen(buf));
	}
}

int get_wan_proto(char *proto)
{
	if (popen_cmd(CMD_NETWORK_WAN_PROTO_GET, _get_wan_proto_call_, proto) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("wan proto: %s\n", proto);

	return 0;
}

int set_wan_proto(char *proto)
{
	char cmd[255];
	EXECUTE_CMD(cmd, "%s=%s", CMD_NETWORK_WAN_PROTO_SET, proto);
	return 0;
}
//---------------------------------------------
//wan username
void _get_wan_username_call_(char *buf, void *username)
{
	if (username && buf)
	{
		memcpy((char *)username, buf, strlen(buf));
	}
}

int get_wan_username(char *username)
{
	if (popen_cmd(CMD_NETWORK_WAN_USERNAME_GET, _get_wan_username_call_, username) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("wan username: %s\n", username);

	return 0;
}

int set_wan_username(char *username)
{
	char cmd[255];
	EXECUTE_CMD(cmd, "%s=%s", CMD_NETWORK_WAN_USERNAME_SET, username);
	return 0;
}
//---------------------------------------------
//wan password
void _get_wan_password_call_(char *buf, void *password)
{
	if (password && buf)
	{
		memcpy((char *)password, buf, strlen(buf));
	}
}

int get_wan_password(char *password)
{
	if (popen_cmd(CMD_NETWORK_WAN_PASSWORD_GET, _get_wan_password_call_, password) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("wan password: %s\n", password);

	return 0;
}

int set_wan_password(char *password)
{
	char cmd[255];
	EXECUTE_CMD(cmd, "%s=%s", CMD_NETWORK_WAN_PASSWORD_SET, password);
	return 0;
}
//---------------------------------------------
//wan ip static
void _get_wan_ipadrr_call_(char *buf, void *ipadrr)
{
	if (ipadrr && buf)
	{
		memcpy((char *)ipadrr, buf, strlen(buf));
	}
}

int get_wan_ipadrr(char *ipadrr)
{
	if (popen_cmd(CMD_NETWORK_WAN_IPADDR_GET, _get_wan_password_call_, ipadrr) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("wan ipadrr: %s\n", ipadrr);

	return 0;
}

int set_wan_ipadrr(char *ipadrr)
{
	char cmd[255];
	EXECUTE_CMD(cmd, "%s=%s", CMD_NETWORK_WAN_IPADDR_SET, ipadrr);
	return 0;
}


