

#ifndef __QOS_TC_H__
#define __QOS_TC_H__


void fw_tc_set_download_speed(int speed);
void fw_tc_set_upload_speed(int speed);

void fw_tc_accept_other_package_by_ip(char *ip);
void fw_tc_accept_other_package_by_port(int port);

void fw_tc_stop();



#endif

