#ifndef __IP_CHECK_H__
#define __IP_CHECK_H__

#include "includes.h"

bool is_ip_str(char *str);


#endif


