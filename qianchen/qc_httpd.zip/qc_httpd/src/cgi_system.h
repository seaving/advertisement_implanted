#ifndef __CGI_SYSTEM_H__
#define __CGI_SYSTEM_H__

#include "common.h"
#include "evhttp_server.h"

int cgi_get_system_info(struct evhttp_request *req, const t_http_server *http_server);
int cgi_reboot(struct evhttp_request *req, const t_http_server *http_server);


#endif


