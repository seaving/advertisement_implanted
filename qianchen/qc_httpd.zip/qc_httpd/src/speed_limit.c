#include "includes.h"

static int g_upspeed = 0;
static int g_downspeed = 0;

int get_upspeed()
{
	return g_upspeed;
}

int get_downspeed()
{
	return g_downspeed;
}

void set_upspeed_value(int s)
{
	if (s < 0)
		s = 0;
	g_upspeed = s;
}

void set_downspeed_value(int s)
{
	if (s < 0)
		s = 0;
	g_downspeed = s;
}

void speed_limit_tc_set_rate(int upload_rate, int download_rate)
{
    LOG_NORMAL_INFO("--------------cxw UP = %u DOWNM = %u", upload_rate, download_rate);
    
	fw_tc_stop();

	fw_tc_del_redirect_to_vir_netdev_rule();
	fw_vir_netdev_destroy();
	fw_vir_netdev_create();
	fw_tc_redirect_to_vir_netdev();

	fw_tc_set_download_speed(download_rate);
	fw_tc_set_upload_speed(upload_rate);
}

int speed_limit_tc_accept_by_hostname(char *hostname)
{
	struct addrinfo *answer, hint, *curr;
	char ipaddr[32] = {0};
	char *ipstr = ipaddr;
	struct sockaddr_in *addr;
	bzero(&hint, sizeof(hint));
	hint.ai_family = AF_INET;
	hint.ai_socktype = SOCK_STREAM;
	
	int ret = getaddrinfo(hostname, NULL, &hint, &answer);
	if (ret != 0)
	{
		LOG_ERROR_INFO("[ %s ] getaddrinfo: %s", hostname, gai_strerror(ret));
		return -1;
	}
	
	for (curr = answer; curr != NULL; curr = curr->ai_next)
	{
		addr = (struct sockaddr_in *)curr->ai_addr;
		memset(ipstr, 0, 32);
		inet_ntop(AF_INET, &addr->sin_addr, ipstr, 16);
		LOG_NORMAL_INFO("simo_patform_tc_accept: %s --- > %s", hostname, ipstr);
		fw_tc_accept_other_package_by_ip(ipstr);
	}
	
	freeaddrinfo(answer);
	return 0;
}

void speed_limit_tc_accept_default()
{
	//--------------------------------------------------------
	//����DNS�˿�
	fw_tc_accept_other_package_by_port(53);
	fw_tc_accept_other_package_by_ip("192.168.43.1");
	//--------------------------------------------------------

	speed_limit_tc_accept_by_hostname("www.manyoubao.com");
	speed_limit_tc_accept_by_hostname("m.manyoubao.com");
	speed_limit_tc_accept_by_hostname("manyoubao.com");
	
	speed_limit_tc_accept_by_hostname("bsp.skyroam.com");
	speed_limit_tc_accept_by_hostname("www.skyroam.com");
	speed_limit_tc_accept_by_hostname("www.skyroam.com.cn");
	speed_limit_tc_accept_by_hostname("skyroam.com.cn");
	
	speed_limit_tc_accept_by_hostname("www.alipay.com");
	speed_limit_tc_accept_by_hostname("m.alipay.com");
	speed_limit_tc_accept_by_hostname("alipay.com");
	
	/*�˴�������������
	speed_limit_tc_accept_by_hostname("");*/

}

void speed_limit_set_rate(int up_speed, int down_speed)
{
	if (up_speed == 0 && down_speed == 0)
	{
		LOG_NORMAL_INFO("up_seed and down_speed is not setting!\n");
		return ;
	}

	if (g_upspeed < 0)
		g_upspeed = 0;
	if (g_downspeed < 0)
		g_downspeed = 0;

	if (up_speed < 0)
		up_speed = g_upspeed;
	if (down_speed < 0)
		down_speed = g_downspeed;

	if (up_speed == 0)
		up_speed = 100 * 1024 * 1024;
	if (down_speed == 0)
		down_speed = 100 * 1024 * 1024;

	g_upspeed = up_speed;
	g_downspeed = down_speed;
	
	LOG_NORMAL_INFO("up_speed = %d, down_speed = %d", up_speed, down_speed);
	
	speed_limit_tc_set_rate(up_speed, down_speed);

	//����Ĭ�ϰ�����
	speed_limit_tc_accept_default();

	//�ٰѰ���������
	//set
	char* wip = speed_limit_wip_file_read();
	if (wip)
	{
		int offset = 0;
		int i = 0;
		
		char buf[64];
		for (i = 0; i < strlen(wip); i ++)
		{
			
			if (offset > 0 && wip[i] == '\n')
			{
				LOG_NORMAL_INFO("set_speed : TC accept: %s", buf);
				fw_tc_accept_other_package_by_ip(buf);
				offset = 0;
			}
			else
			{
				buf[offset ++] = wip[i];
				buf[offset] = 0;
			}
		}
		
		free(wip);
		wip = NULL;
	}
}


