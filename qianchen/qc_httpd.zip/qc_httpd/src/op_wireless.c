#include "includes.h"

#define CMD_WIFI_SSID_GET			"uci get wireless.@wifi-iface[%d].ssid"
#define CMD_WIFI_SSID_SET			"uci set wireless.@wifi-iface[%d].ssid"

#define CMD_WIFI_TXPOWER_GET		"uci get wireless.@wifi-device[%d].txpower"
#define CMD_WIFI_TXPOWER_SET		"uci set wireless.@wifi-device[%d].txpower"

#define CMD_WIFI_CHANNEL_GET		"uci get wireless.@wifi-device[%d].channel"
#define CMD_WIFI_CHANNEL_SET		"uci set wireless.@wifi-device[%d].channel"

#define CMD_WIFI_MODE_GET			"uci get wireless.@wifi-iface[%d].mode"
#define CMD_WIFI_MODE_SET			"uci set wireless.@wifi-iface[%d].mode"

#define CMD_WIFI_ENCRYPTION_GET		"uci get wireless.@wifi-iface[%d].encryption"
#define CMD_WIFI_ENCRYPTION_SET		"uci set wireless.@wifi-iface[%d].encryption"

#define CMD_WIFI_KEY_GET			"uci get wireless.@wifi-iface[%d].key"
#define CMD_WIFI_KEY_SET			"uci set wireless.@wifi-iface[%d].key"

#define CMD_WIFI_DISABLED_GET		"uci get wireless.@wifi-device[%d].disabled"
#define CMD_WIFI_DISABLED_SET		"uci set wireless.@wifi-device[%d].disabled"

#define CMD_WIFI_HTMODE_GET			"uci get wireless.@wifi-device[%d].htmode"
#define CMD_WIFI_HTMODE_SET			"uci set wireless.@wifi-device[%d].htmode"

#define CMD_WIFI_HWMODE_GET			"uci get wireless.@wifi-device[%d].hwmode"
#define CMD_WIFI_HWMODE_SET			"uci set wireless.@wifi-device[%d].hwmode"

#define CMD_WIFI_HIDDEN_GET			"uci get wireless.@wifi-iface[%d].hidden"
#define CMD_WIFI_HIDDEN_SET			"uci set wireless.@wifi-iface[%d].hidden"

//---------------------------------------------
//ssid
void _get_wifi_ssid_call_(char *buf, void *ssid)
{
	if (ssid && buf)
	{
		memcpy((char *)ssid, buf, strlen(buf));
	}
}

int get_wifi_ssid(int witch, char *ssid)
{
	char cmd[256];
	snprintf(cmd, 255, CMD_WIFI_SSID_GET, witch);
	if (popen_cmd(cmd, _get_wifi_ssid_call_, ssid) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("ssid: %s\n", ssid);

	return 0;
}

int set_wifi_ssid(int witch, char *ssid)
{
	char cmd[255];
	EXECUTE_CMD(cmd, CMD_WIFI_SSID_SET"=%s", witch, ssid);
	return 0;
}
//---------------------------------------------
//���߹���
void _get_wifi_txpower_call_(char *buf, void *txpower)
{
	if (txpower && buf)
	{
		memcpy((char *)txpower, buf, strlen(buf));
	}
}

int get_wifi_txpower(int witch)
{
	char txpower[10] = {0};
	char cmd[256];
	snprintf(cmd, 255, CMD_WIFI_TXPOWER_GET, witch);

	if (popen_cmd(cmd, _get_wifi_txpower_call_, txpower) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("txpower: %s\n", txpower);

	return atoi(txpower);
}

int set_wifi_txpower(int witch, unsigned char txpower)
{
	char cmd[255];
	EXECUTE_CMD(cmd, CMD_WIFI_TXPOWER_SET"=%d", witch, txpower);
	return 0;
}
//---------------------------------------------
//�����ŵ�
void _get_wifi_channel_call_(char *buf, void *channel)
{
	if (channel && buf)
	{
		memcpy((char *)channel, buf, strlen(buf));
	}
}

int get_wifi_channel(int witch, char *channel)
{
	char cmd[256];
	snprintf(cmd, 255, CMD_WIFI_CHANNEL_GET, witch);

	if (popen_cmd(cmd, _get_wifi_channel_call_, channel) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("channel: %s\n", channel);

	return 0;
}

int set_wifi_channel(int witch, char *channel)
{
	char cmd[255];
	EXECUTE_CMD(cmd, CMD_WIFI_CHANNEL_SET"=%s", witch, channel);
	return 0;
}
//---------------------------------------------
//����ģʽ
void _get_wifi_mode_call_(char *buf, void *mode)
{
	if (mode && buf)
	{
		memcpy((char *)mode, buf, strlen(buf));
	}
}

int get_wifi_mode(int witch, char *mode)
{
	char cmd[256];
	snprintf(cmd, 255, CMD_WIFI_MODE_GET, witch);

	if (popen_cmd(cmd, _get_wifi_mode_call_, mode) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("mode: %s\n", mode);

	return 0;
}

int set_wifi_mode(int witch, char *mode)
{
	char cmd[255];
	EXECUTE_CMD(cmd, CMD_WIFI_MODE_SET"=%s", witch, mode);
	return 0;
}
//---------------------------------------------
//encryption
void _get_wifi_encryption_call_(char *buf, void *encryption)
{
	if (encryption && buf)
	{
		memcpy((char *)encryption, buf, strlen(buf));
	}
}

int get_wifi_encryption(int witch, char *encryption)
{
	char cmd[256];
	snprintf(cmd, 255, CMD_WIFI_ENCRYPTION_GET, witch);

	if (popen_cmd(cmd, _get_wifi_encryption_call_, encryption) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("encryption: %s\n", encryption);

	return 0;
}

int set_wifi_encryption(int witch, char *encryption)
{
	char cmd[255];
	EXECUTE_CMD(cmd, CMD_WIFI_ENCRYPTION_SET"=%s", witch, encryption);
	return 0;
}
//---------------------------------------------
//key(����)
void _get_wifi_key_call_(char *buf, void *key)
{
	if (key && buf)
	{
		memcpy((char *)key, buf, strlen(buf));
	}
}

int get_wifi_key(int witch, char *key)
{
	char cmd[256];
	snprintf(cmd, 255, CMD_WIFI_KEY_GET, witch);

	if (popen_cmd(cmd, _get_wifi_key_call_, key) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("key: %s\n", key);

	return 0;
}

int set_wifi_key(int witch, char *key)
{
	char cmd[255];
	EXECUTE_CMD(cmd, CMD_WIFI_KEY_SET"=%s", witch, key);
	return 0;
}
//---------------------------------------------
//���߿���
void _get_wifi_disabled_call_(char *buf, void *disabled)
{
	if (disabled && buf)
	{
		memcpy((char *)disabled, buf, strlen(buf));
	}
}

int get_wifi_disabled(int witch)
{
	char disabled[10] = {0};
	char cmd[256];
	snprintf(cmd, 255, CMD_WIFI_DISABLED_GET, witch);
	if (popen_cmd(cmd, _get_wifi_disabled_call_, disabled) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("disabled: %s\n", disabled);

	return atoi(disabled);
}

int set_wifi_disabled(int witch, unsigned char disabled)
{
	char cmd[255];
	EXECUTE_CMD(cmd, CMD_WIFI_DISABLED_SET"=%d", witch, disabled);
	return 0;
}
//---------------------------------------------
//���ߴ���
void _get_wifi_htmode_call_(char *buf, void *htmode)
{
	if (htmode && buf)
	{
		memcpy((char *)htmode, buf, strlen(buf));
	}
}

int get_wifi_htmode(int witch, char *htmode)
{
	char cmd[256];
	snprintf(cmd, 255, CMD_WIFI_HTMODE_GET, witch);

	if (popen_cmd(cmd, _get_wifi_htmode_call_, htmode) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("htmode: %s\n", htmode);

	return 0;
}

int set_wifi_htmode(int witch, char *htmode)
{
	char cmd[255];
	EXECUTE_CMD(cmd, CMD_WIFI_HTMODE_SET"=%s", witch, htmode);
	return 0;
}
//---------------------------------------------
//���ߴ���
void _get_wifi_hwmode_call_(char *buf, void *hwmode)
{
	if (hwmode && buf)
	{
		memcpy((char *)hwmode, buf, strlen(buf));
	}
}

int get_wifi_hwmode(int witch, char *hwmode)
{
	char cmd[256];
	snprintf(cmd, 255, CMD_WIFI_HWMODE_GET, witch);

	if (popen_cmd(cmd, _get_wifi_hwmode_call_, hwmode) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("hwmode: %s\n", hwmode);

	return 0;
}

int set_wifi_hwmode(int witch, char *hwmode)
{
	char cmd[255];
	EXECUTE_CMD(cmd, CMD_WIFI_HWMODE_SET"=%s", witch, hwmode);
	return 0;
}
//---------------------------------------------
//��������
void _get_wifi_hidden_call_(char *buf, void *hidden)
{
	if (hidden && buf)
	{
		memcpy((char *)hidden, buf, strlen(buf));
	}
}

int get_wifi_hidden(int witch)
{
	char cmd[256];
	snprintf(cmd, 255, CMD_WIFI_HIDDEN_GET, witch);

	char hidden[5] = {0};
	if (popen_cmd(cmd, _get_wifi_hidden_call_, hidden) < 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("hidden: %s\n", hidden);

	return atoi(hidden);
}

int set_wifi_hidden(int witch, unsigned char hidden)
{
	char cmd[255];
	EXECUTE_CMD(cmd, CMD_WIFI_HIDDEN_SET"=%d", witch, hidden);
	return 0;
}
//---------------------------------------------


