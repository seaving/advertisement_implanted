
#include "includes.h"

//��ʼ��tc����
static void _fw_tc_init(char *dev, char *dir, int rate)
{
	char cmd[256];
	int i, j;
	char seg[32] = {0};
	int segcnt = get_segment_count(LAN_DEV);
	if (segcnt <= 0 || segcnt > 255)
	{
		LOG_ERROR_INFO("get segment count error!\n");
		return ;
	}
	get_segment(seg, LAN_DEV);
	char *p = strchr(seg, '.');
	if (p)
		p = strchr(++ p, '.');
	if (p)
		*p = 0;
	
	//���������
	EXECUTE_CMD(cmd, "tc qdisc add dev %s root handle 1: htb", dev);

	for (i = 1; i <= segcnt; i ++)
	{
		//������Ҷ��(������ɸѡ)
		EXECUTE_CMD(cmd, "tc class add dev %s parent 1: classid 1:%d htb rate 1000mbps ceil 1000mbps prio 1 burst 20k", dev, i);

		for (j = 1; j <= 255; j ++)
		{
			//����������Ҷ(IP)
			EXECUTE_CMD(cmd, "tc class add dev %s parent 1:%d classid 2:%d htb rate 1000mbps ceil 1000mbps prio 1 burst 20k", dev, i, j);
			
			//������Ҷ�ӵ�filter
			EXECUTE_CMD(cmd, "tc filter add dev %s parent 1:%d protocol ip prio 1 u32 match ip %s %s.%d.%d flowid 2:%d", 
								dev, i, dir, seg, 255 - segcnt + i - 1, j, j);
		}
	}
}

//ɾ��tc����
static void _fw_tc_del(char *dev)
{
	if (! dev)
		return ;
	
	char cmd[256];
	EXECUTE_CMD(cmd, "tc qdisc del dev %s root", dev);
}

void fw_tc_stop()
{
	_fw_tc_del(LAN_DEV);
	_fw_tc_del(WAN_DEV);
}

//���÷��зǱ�����������
static void _fw_tc_accept_other_package(char *dev, char *dir, char *match)
{
	if (! dev || ! dir || ! match)
		return ;
	char cmd[256];
	EXECUTE_CMD(cmd, "tc filter add dev %s parent 1: protocol ip prio 2 u32 match ip %s %s flowid 1:2", dev, dir, match);
}

void fw_tc_accept_other_package_by_ip(char *ip)
{
	_fw_tc_accept_other_package(LAN_DEV, "src", ip);
	_fw_tc_accept_other_package(WAN_DEV, "dst", ip);
}

void fw_tc_accept_other_package_by_port(int port)
{
	char str_port[32];
	sprintf(str_port, "%d", port);
	_fw_tc_accept_other_package(LAN_DEV, "sport", str_port);

	_fw_tc_accept_other_package(WAN_DEV, "dport", str_port);
}

//��װ���к������ٶ����ýӿ�
void fw_tc_set_download_speed(int speed)
{
	_fw_tc_init(LAN_DEV, "dst", speed);
}

void fw_tc_set_upload_speed(int speed)
{
	_fw_tc_init(WAN_DEV, "src", speed);
}


