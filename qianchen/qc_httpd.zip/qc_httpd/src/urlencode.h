#ifndef __URL_ENCODE_H__
#define __URL_ENCODE_H__

int url_encode(const unsigned char *input, int in_len, unsigned char *output, int out_size);


#endif

