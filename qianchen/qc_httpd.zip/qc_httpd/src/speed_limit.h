#ifndef __SPEED_LIMIT_H__
#define __SPEED_LIMIT_H__


void set_upspeed_value(int s);
void set_downspeed_value(int s);

void speed_limit_set_rate(int up_speed, int down_speed);


#endif



