#ifndef __ZH_TO_UTF8_H__
#define __ZH_TO_UTF8_H__


char *utf8_encode(char *s);
char *unicode_encode(char *s);

void utf8_encode_free(void *utf);

#endif


