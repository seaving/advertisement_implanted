#!/bin/bash

PLATFORMS=$1
DEBUG_ON=$2
VERSION=`cat src/version.h | grep -w VERSION | awk -F " " '{print $3}' | awk -F '"' '{print $2}'`
TARGET_NAME="qcdog"
useage() {
	echo "PLATFORMS is selection, [0]: AR9344, [1]: MT7620, [2]: PC, [3]: x86."
	echo "DEBUG_ON is selection, [0]: disable log print, [1]: log enable."
	#echo "TARGET_NAME is the program bin name by yourself."
}

[ $# -eq 1 ] && [ "$1" == "-h" ] && {
	useage
	exit
}

[ -z "$VERSION" ] && echo "not define version!" && exit

[ -z "$PLATFORMS" ] || [ -z "$TARGET_NAME" ] || [ -z "$DEBUG_ON" ] && {
	echo "please input PLATFORMS, DEBUG_ON!"
	useage
	exit
}

case $PLATFORMS in
	"0") PLATFORMS="ar9344"
	;;
	"1") PLATFORMS="mt7620"
	;;
	"2") PLATFORMS="pc"
	;;
	"3") PLATFORMS="x86"
	;;
	*) echo "PLATFORMS is selection, [0]: AR9344, [1]: MT7620, [2]: PC, [3]: x86.";exit
	;;
esac
rm -rf makefile
sync
cp -rf build/makefile-$PLATFORMS makefile
sync

make clean
make ID="1" PLATFORMS=$PLATFORMS DEBUG_ON=$DEBUG_ON TARGET_NAME=$TARGET_NAME VERSION=$VERSION 2>./complie.log

complie_log=`cat ./complie.log`
[ -n "$complie_log" ] && {
	err=`cat ./complie.log | grep -w "error:" | wc -l`
	warn=`cat ./complie.log | grep -w "warning:" | wc -l`

	if [ "$err" == "0" ] && [ "$warn" == "1" ]
	then
		complie_log=`echo "$complie_log" | grep "warning: gethostbyname"`
		if [ -n "$complie_log" ]
		then
			echo > ./complie.log
		else
			echo "$complie_log"
			exit
		fi
	else
		echo "$complie_log"
		exit
	fi
}

rm -rf ../package/app/$TARGET_NAME
cp -rf hex/$TARGET_NAME ../package/app/
cp -rf apfree.ca ../package/app/
cp -rf apfree.crt ../package/app/
cp -rf apfree.key ../package/app/

rm -rf ../package/app/wifidog
mkdir ../package/app/wifidog

cp -rf internet-offline.html 	../package/app/wifidog/
cp -rf authserver-offline.html 	../package/app/wifidog/
cp -rf wifidog-msg.html 		../package/app/wifidog/
cp -rf wifidog-msg.html.front 	../package/app/wifidog/
cp -rf wifidog-msg.html.midle 	../package/app/wifidog/
cp -rf wifidog-msg.html.rear 	../package/app/wifidog/
cp -rf wifidog-redir.html 		../package/app/wifidog/
cp -rf wifidog-redir.html.front ../package/app/wifidog/
cp -rf wifidog-redir.html.rear 	../package/app/wifidog/

sync
exit
