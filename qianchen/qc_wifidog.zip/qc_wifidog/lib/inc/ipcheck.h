#ifndef __IP_CHECK_H__
#define __IP_CHECK_H__


bool is_ip_str(char *str);


#endif


