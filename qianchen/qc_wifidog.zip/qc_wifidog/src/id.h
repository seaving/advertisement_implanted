#ifndef __ID_H__
#define __ID_H__

#define ID             "1"

#define PLATFORMS      "x86"

#define MODULE_NAME	 "qcdog"


#endif
