
#ifndef __SHAM_H__
#define __SHAM_H__

int InitSham(int * sham_id, unsigned int sham_size, key_t sham_key);

#endif

