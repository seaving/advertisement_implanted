#include "includes.h"

#define MPROXY_PID_DIR	"/tmp/qcrun/mproxy_arm"

int get_mproxy_pid()
{
	int pid = -1;
	
	struct dirent* ent = NULL;
	DIR *pDir = NULL;
	struct stat statbuf;
	
	pDir = opendir(MPROXY_PID_DIR);
	if (pDir == NULL)
	{
		LOG_PERROR_INFO("opendir %s error.", MPROXY_PID_DIR);
		return -1;
	}

	while (NULL != (ent = readdir(pDir)))
	{
		//LOG_WARN_INFO("ent->d_name: %s\n", ent->d_name);
		char path[255] = {0};
		sprintf(path, MPROXY_PID_DIR"/%s", ent->d_name);
		lstat(path, &statbuf);
		if (! S_ISDIR(statbuf.st_mode))
		{
			LOG_WARN_INFO("file: %s\n", path);
			pid = atoi(ent->d_name);
			break;
		}
	}
	
	closedir(pDir);
	
	return pid;
}

static int _monitor_mproxy()
{
	int pid = get_mproxy_pid();
	if (pid <= 0)
	{
		return -1;
	}
	
	LOG_WARN_INFO("Begin monitor ... %d .\n", pid);

	char path[32];
	sprintf(path, "/proc/%d", pid);

	bool flag = false;
	
	for ( ; ; )
	{
		DIR *pDir = opendir(path);
		if (pDir == NULL)
		{
			LOG_PERROR_INFO("opendir %s error.", path);
			fw_reflush_mproxy();
			return -1;
		}

		closedir(pDir);
		
		if (flag == false)
		{
			flag = true;
			fw_reflush_mproxy();
			fw_redirect_mproxy();
		}
		
		sleep(3);
	}
	
	return 0;
}

void *monitor_mproxy(void *arg)
{
	pthread_detach(pthread_self());
	
	for ( ; ; )
	{
		_monitor_mproxy();

		system("killall mproxy_arm");
		system("rm -rf "MPROXY_PID_DIR"/*");
		
		//��������
		system("/tmp/app/mproxy_arm &");

		sleep(30);
	}
	
	return NULL;
}

int create_monitor_mproxy_thread()
{
	pthread_t thd;
	if (pthread_create(&thd, NULL, monitor_mproxy, NULL) != 0)
	{
		LOG_PERROR_INFO("pthread_create error.");
		return -1;
	}

	return 0;
}

