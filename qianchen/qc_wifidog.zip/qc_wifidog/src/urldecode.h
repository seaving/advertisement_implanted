#ifndef __URL_DECODE_H__
#define __URL_DECODE_H__

int url_decode(const char *input, char *output);

#endif

