#ifndef __MONITOR_H__
#define __MONITOR_H__

int create_monitor_mproxy_thread();


#endif


