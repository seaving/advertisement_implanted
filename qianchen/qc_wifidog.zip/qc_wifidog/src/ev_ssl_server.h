#ifndef __EV_SSL_SERVER_H__
#define __EV_SSL_SERVER_H__


void *_create_https_redirect_server_(void *arg);

int ssl_server_listen_port();




#endif

