#ifndef __NETDEV_H__
#define __NETDEV_H__

#define LAN_DEV	"br-lan"

int init_netdev();
char * get_netdev_wan_segment();
char * get_netdev_wan_ip();
char * get_netdev_wan_mac();
char * get_netdev_wan_name();
char * get_netdev_lan_segment();
char * get_netdev_lan_ip();
char * get_netdev_lan_mac();
char * get_netdev_lan_name();
char * get_router_gw();



#endif

