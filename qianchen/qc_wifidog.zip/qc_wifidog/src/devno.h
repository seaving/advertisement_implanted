#ifndef __DEVNO_H__
#define __DEVNO_H__ 1

#define DEVNO_LEN	32

extern char g_devNo[DEVNO_LEN+1];

int init_devNo();

#endif

