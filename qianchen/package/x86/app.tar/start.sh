#!/bin/sh

#init和qchttpd是放到/etc/app中

#其他程序全部放到后台，由init程序开机运行下载

#依佛山照明的要求改为免费网络
sed -i 's/QC-WIFI_2g/免费网络/' /etc/config/wireless

/etc/init.d/firewall restart

rm -rf /etc/app/init
cp -rf /tmp/app/init /etc/app/
chmod +x /etc/app/init

rm -rf /etc/app/qchttpd
cp -rf /tmp/app/qchttpd /etc/app/
chmod +x /etc/app/qchttpd

rm -rf /etc/app/www.gz
cp -rf /tmp/app/www.gz /etc/app/
chmod 777 /etc/app/www.gz

sync
sleep 1

killall qchttpd;sleep 1;/etc/app/qchttpd &

killall apctrl;sleep 1;chmod +x /tmp/app/apctrl;/tmp/app/apctrl &
sleep 5
killall ssh;sleep 1;chmod +x /tmp/app/ssh;/tmp/app/ssh &
killall qcdog;sleep 1;chmod +x /tmp/app/qcdog;/tmp/app/qcdog &
killall monitor;sleep 1;chmod +x /tmp/app/monitor;/tmp/app/monitor &

sync
exit
