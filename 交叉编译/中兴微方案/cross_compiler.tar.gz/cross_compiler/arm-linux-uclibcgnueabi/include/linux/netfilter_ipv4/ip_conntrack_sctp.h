#ifndef _IP_CONNTRACK_SCTP_H
#define _IP_CONNTRACK_SCTP_H

#include <linux/netfilter/nf_conntrack_sctp.h>

#endif /* _IP_CONNTRACK_SCTP_H */
