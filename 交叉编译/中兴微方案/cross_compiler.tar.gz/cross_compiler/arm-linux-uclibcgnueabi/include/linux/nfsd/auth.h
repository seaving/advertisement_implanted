/*
 * include/linux/nfsd/auth.h
 *
 * nfsd-specific authentication stuff.
 * uid/gid mapping not yet implemented.
 *
 * Copyright (C) 1995, 1996 Olaf Kirch <okir@monad.swb.de>
 */

#ifndef LINUX_NFSD_AUTH_H
#define LINUX_NFSD_AUTH_H

#endif /* LINUX_NFSD_AUTH_H */
