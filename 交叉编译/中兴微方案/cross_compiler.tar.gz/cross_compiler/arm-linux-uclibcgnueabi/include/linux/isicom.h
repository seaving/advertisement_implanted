#ifndef _LINUX_ISICOM_H
#define _LINUX_ISICOM_H

/*#define		ISICOM_DEBUG*/
/*#define		ISICOM_DEBUG_DTR_RTS*/


#endif	/*	ISICOM_H	*/
