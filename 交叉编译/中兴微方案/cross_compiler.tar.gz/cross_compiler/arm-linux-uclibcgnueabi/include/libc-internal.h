#ifndef _LIBC_INTERNAL_H
#define _LIBC_INTERNAL_H 1
#endif
